// STM32 interactive test console for GSM library
// Targets STM32H7/F4/etc with CubeMX HAL: UART7 = Modem, USART1 = Console
#include "app.hpp"
#include "gsm/modem/modem.hpp"
#include "gsm/ports/stm32/gsm_port_stm32.hpp"
#include "gsm/tools/serial_bridge.hpp"
#include "usart.h"
#include <cstdio>
#include <cstring>

using namespace gsm;

// Hardware drivers
static port::Stm32Uart<512> gsm_uart(&huart7);
static port::Stm32Uart<256> dbg_uart(&huart1);
static port::Stm32Clock     clk;

// Optional: define PWRKEY and RESET pins (example: GPIOB Pin 12 for PWRKEY)
// static port::Stm32PowerControl pwr(GPIOB, GPIO_PIN_12);
static Modem               modem(gsm_uart, clk, kSim800 /*, &pwr */);
static tools::SerialBridge bridge(dbg_uart, modem);
static const log::Channel  app_log{"app", log::Level::Debug};

// Route internal library logs to debug console (with ANSI color codes)
static void dbg_write(void*, const uint8_t* data, uint16_t len)
{ dbg_uart.write(data, len); }
static log::WriterSink dbg_sink{&dbg_write, nullptr};

// Interactive CLI state
static char     cmd_line[128];
static uint16_t cmd_idx = 0;

namespace cli
{
static constexpr const char* CLR_RESET  = "\033[0m";
static constexpr const char* CLR_TITLE  = "\033[1;35m";
static constexpr const char* CLR_MENU   = "\033[1;36m";
static constexpr const char* CLR_KEY    = "\033[1;33m";
static constexpr const char* CLR_VAL    = "\033[1;32m";
static constexpr const char* CLR_ERR    = "\033[1;31m";
static constexpr const char* CLR_PROMPT = "\033[1;34m";

static void print(const char* str)
{
    if (str)
        dbg_uart.write(reinterpret_cast<const uint8_t*>(str),
                       static_cast<uint16_t>(std::strlen(str)));
}

static void printf(const char* fmt, ...) __attribute__((format(printf, 1, 2)))
{
    char    buf[160];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n > 0) dbg_uart.write(reinterpret_cast<const uint8_t*>(buf), static_cast<uint16_t>(n));
}

static void show_menu()
{
    printf("\r\n%s╔══════════════════════════════════════════════════════════╗%s\r\n", CLR_TITLE,
           CLR_RESET);
    printf("%s║           GSM MODEM INTERACTIVE TEST CONSOLE             ║%s\r\n", CLR_TITLE,
           CLR_RESET);
    printf("%s╚══════════════════════════════════════════════════════════╝%s\r\n", CLR_TITLE,
           CLR_RESET);
    printf(" %sm%s  - Show this menu            %sq%s  - Queue status / details\r\n", CLR_KEY,
           CLR_RESET, CLR_KEY, CLR_RESET);
    printf(" %si%s  - Live modem info / status  %sp%s  - Toggle queue pause/resume\r\n", CLR_KEY,
           CLR_RESET, CLR_KEY, CLR_RESET);
    printf(" %ss%s  - Refresh status sweep      %sx%s  - Stop all & clear queue\r\n", CLR_KEY,
           CLR_RESET, CLR_KEY, CLR_RESET);
    printf(" %sr%s  - Scan unread SMS           %sd%s  - Clean read SMS from storage\r\n", CLR_KEY,
           CLR_RESET, CLR_KEY, CLR_RESET);
    printf(" %sb%s  - Check SIM Balance (USSD)  %sh%s  - Hangup active call (Urgent)\r\n", CLR_KEY,
           CLR_RESET, CLR_KEY, CLR_RESET);
    printf(" %sT%s  - Toggle Log Timestamps     %sC%s  - Toggle Log ANSI Colors\r\n", CLR_KEY,
           CLR_RESET, CLR_KEY, CLR_RESET);
    printf(" %sP%s  - Toggle Passthrough Bridge %sR%s  - Reset modem FSM\r\n", CLR_KEY, CLR_RESET,
           CLR_KEY, CLR_RESET);
    printf(" %sc%s  - Clear terminal screen\r\n", CLR_KEY, CLR_RESET);
    printf("----------------------------------------------------------\r\n");
    printf(" %ssms <num> <text>%s  : Send SMS (e.g. sms 09037744527 سلام)\r\n", CLR_MENU,
           CLR_RESET);
    printf(" %sdial <num>%s        : Dial voice call (e.g. dial 09037744527)\r\n", CLR_MENU,
           CLR_RESET);
    printf(" %sussd <code>%s       : Custom USSD (e.g. ussd *140#)\r\n", CLR_MENU, CLR_RESET);
    printf(" %sread <idx>%s        : Read SMS by index (e.g. read 1)\r\n", CLR_MENU, CLR_RESET);
    printf(" %sdel <idx>%s         : Delete SMS by index\r\n", CLR_MENU, CLR_RESET);
    printf(" %sat <cmd>%s          : Direct raw AT (e.g. at AT+CSQ)\r\n", CLR_MENU, CLR_RESET);
    printf("----------------------------------------------------------\r\n");
    printf("%sgsm>%s ", CLR_PROMPT, CLR_RESET);
}

static void show_status()
{
    const auto& st = modem.status();
    printf("\r\n%s--- MODEM STATUS ---%s\r\n", CLR_TITLE, CLR_RESET);
    printf(" FSM State  : %s%s%s (Activity: %s, Step: %s)\r\n", CLR_VAL, modem.state_name(),
           CLR_RESET, modem.activity(), modem.step());
    printf(" Signal     : CSQ=%s%u%s | RSSI=%s%ddBm%s | Bars=%s%u/5%s\r\n", CLR_VAL, st.csq_raw,
           CLR_RESET, CLR_VAL, st.rssi_dbm, CLR_RESET, CLR_VAL, st.signal_bars(), CLR_RESET);
    printf(" Network    : %s%s%s (%s) | Reg code: %u\r\n", st.network_ready ? CLR_VAL : CLR_ERR,
           st.network_ready ? "READY" : "NO_NET", CLR_RESET, to_string(st.registration),
           static_cast<unsigned>(st.registration));
    printf(" SIM State  : %s%s%s (Ready flag: %d)\r\n", st.sim_ready ? CLR_VAL : CLR_ERR,
           to_string(st.sim_state), CLR_RESET, st.sim_ready);
    printf(" Operator   : %s%s%s (Detected: %s%s%s)\r\n", CLR_VAL,
           st.operator_name.empty() ? "N/A" : st.operator_name.c_str(), CLR_RESET, CLR_KEY,
           to_string(st.op), CLR_RESET);
    printf(" SMS Storage: %s%u / %u%s msgs\r\n", st.storage_full() ? CLR_ERR : CLR_VAL, st.sms_used,
           st.sms_total, CLR_RESET);
    printf(" Call State : %s%s%s (Peer: %s)\r\n", CLR_VAL, to_string(modem.call().state()),
           CLR_RESET, modem.call().peer() ? modem.call().peer() : "none");
    printf(" Last Sync  : %lu ms ago\r\n",
           st.updated_at_ms ? static_cast<unsigned long>(clk.millis() - st.updated_at_ms) : 0UL);
    printf("--------------------\r\n%sgsm>%s ", CLR_PROMPT, CLR_RESET);
}

static void show_queue()
{
    printf("\r\n%s--- QUEUE STATUS ---%s\r\n", CLR_TITLE, CLR_RESET);
    printf(" Queue State: %s%s%s | Size: %s%u / %u%s\r\n", modem.queue_paused() ? CLR_ERR : CLR_VAL,
           modem.queue_paused() ? "PAUSED" : "ACTIVE", CLR_RESET, CLR_VAL, modem.queue_size(),
           JobQueue::capacity(), CLR_RESET);

    const auto& cur = modem.current_job();
    if (cur.kind != JobKind::None)
    {
        printf(" Current Job: #%u %s%s%s (Try: %u/%u, State: %s)\r\n", cur.id, CLR_KEY,
               to_string(cur.kind), CLR_RESET, cur.attempts, cur.max_attempts,
               to_string(cur.state));
    }
    else
    {
        printf(" Current Job: None (Engine idle)\r\n");
    }

    for (uint8_t i = 0; i < modem.queue_size(); ++i)
    {
        const auto* j = modem.queued(i);
        if (!j) continue;
        printf("  [%u] #%u %s (Urgent: %s, Num: %s)\r\n", i, j->id, to_string(j->kind),
               j->urgent ? "YES" : "no", j->number.empty() ? "-" : j->number.c_str());
    }
    printf("--------------------\r\n%sgsm>%s ", CLR_PROMPT, CLR_RESET);
}

static void process_cmd(char* line)
{
    while (*line == ' ')
        ++line;
    if (!*line)
    {
        printf("%sgsm>%s ", CLR_PROMPT, CLR_RESET);
        return;
    }

    if (std::strcmp(line, "m") == 0)
    {
        show_menu();
        return;
    }
    if (std::strcmp(line, "i") == 0)
    {
        show_status();
        return;
    }
    if (std::strcmp(line, "q") == 0)
    {
        show_queue();
        return;
    }
    if (std::strcmp(line, "s") == 0)
    {
        printf("Triggering status sweep...\r\n");
        modem.refresh_status();
        return;
    }
    if (std::strcmp(line, "r") == 0)
    {
        printf("Scanning unread SMS...\r\n");
        modem.scan_sms();
        return;
    }
    if (std::strcmp(line, "d") == 0)
    {
        printf("Deleting read SMS...\r\n");
        modem.delete_read_sms();
        return;
    }
    if (std::strcmp(line, "h") == 0)
    {
        printf("Urgent hangup queued...\r\n");
        modem.hang_up();
        return;
    }
    if (std::strcmp(line, "b") == 0)
    {
        printf("Querying balance for operator %s%s%s...\r\n", CLR_KEY, to_string(modem.status().op),
               CLR_RESET);
        JobId id = modem.check_balance();
        printf("Queued USSD Job #%u\r\n", id);
        return;
    }
    if (std::strcmp(line, "T") == 0)
    {
        bool next = !log::Registry::timestamps();
        log::Registry::set_timestamps(next);
        printf("Log Timestamps %s%s%s\r\n", CLR_VAL, next ? "ENABLED" : "DISABLED", CLR_RESET);
        return;
    }
    if (std::strcmp(line, "C") == 0)
    {
        bool next = !log::Registry::color();
        log::Registry::set_color(next);
        printf("Log Colors %s%s%s\r\n", CLR_VAL, next ? "ENABLED" : "DISABLED", CLR_RESET);
        return;
    }
    if (std::strcmp(line, "x") == 0)
    {
        printf("%sStopping all and clearing queue!%s\r\n", CLR_ERR, CLR_RESET);
        modem.stop_all(false);
        return;
    }
    if (std::strcmp(line, "p") == 0)
    {
        if (modem.queue_paused())
        {
            modem.resume_queue();
            printf("%sQueue resumed.%s\r\n", CLR_VAL, CLR_RESET);
        }
        else
        {
            modem.pause_queue();
            printf("%sQueue paused.%s\r\n", CLR_ERR, CLR_RESET);
        }
        return;
    }
    if (std::strcmp(line, "R") == 0)
    {
        printf("%sResetting modem FSM...%s\r\n", CLR_ERR, CLR_RESET);
        modem.reset();
        return;
    }
    if (std::strcmp(line, "c") == 0)
    {
        print("\033[2J\033[H");
        show_menu();
        return;
    }
    if (std::strcmp(line, "P") == 0)
    {
        bool next = !bridge.passthrough();
        bridge.set_passthrough(next);
        printf("%sPassthrough Bridge %s!%s (Type 'e' to return)\r\n", CLR_TITLE,
               next ? "ENABLED" : "DISABLED", CLR_RESET);
        return;
    }

    if (std::strncmp(line, "sms ", 4) == 0)
    {
        char* p = line + 4;
        while (*p == ' ')
            ++p;
        char* num = p;
        char* sep = std::strchr(p, ' ');
        if (!sep)
        {
            printf("%sUsage: sms <number> <text>%s\r\n", CLR_ERR, CLR_RESET);
            return;
        }
        *sep       = '\0';
        char* text = sep + 1;
        while (*text == ' ')
            ++text;
        JobId id = modem.send_sms(num, text);
        if (id != kInvalidJob)
            printf("%sQueued SMS #%u to %s%s\r\n", CLR_VAL, id, num, CLR_RESET);
        else
            printf("%sFailed to queue SMS (queue full?)%s\r\n", CLR_ERR, CLR_RESET);
        return;
    }

    if (std::strncmp(line, "dial ", 5) == 0)
    {
        char* num = line + 5;
        while (*num == ' ')
            ++num;
        JobId id = modem.dial(num);
        if (id != kInvalidJob)
            printf("%sQueued Dial #%u to %s%s\r\n", CLR_VAL, id, num, CLR_RESET);
        else
            printf("%sFailed to queue Dial%s\r\n", CLR_ERR, CLR_RESET);
        return;
    }

    if (std::strncmp(line, "ussd ", 5) == 0)
    {
        char* code = line + 5;
        while (*code == ' ')
            ++code;
        JobId id = modem.ussd(code);
        printf("%sQueued custom USSD #%u (%s)%s\r\n", CLR_VAL, id, code, CLR_RESET);
        return;
    }

    if (std::strncmp(line, "read ", 5) == 0)
    {
        int   idx = std::atoi(line + 5);
        JobId id  = modem.read_sms(static_cast<int16_t>(idx));
        printf("Queued Read SMS #%u for index %d\r\n", id, idx);
        return;
    }

    if (std::strncmp(line, "del ", 4) == 0)
    {
        int idx = std::atoi(line + 4);
        printf("Deleting index %d...\r\n", idx);
        modem.sms().start_delete_index(static_cast<int16_t>(idx));
        return;
    }

    if (std::strncmp(line, "at ", 3) == 0)
    {
        char* at_cmd = line + 3;
        while (*at_cmd == ' ')
            ++at_cmd;
        if (modem.at().idle())
        {
            printf("Sending direct: %s\r\n", at_cmd);
            modem.at().execute(at_cmd, 5000, &bridge);
        }
        else
        {
            printf("%sAT Engine busy with FSM!%s\r\n", CLR_ERR, CLR_RESET);
        }
        return;
    }

    printf("%sUnknown command: %s (Type 'm' for menu)%s\r\n", CLR_ERR, line, CLR_RESET);
    printf("%sgsm>%s ", CLR_PROMPT, CLR_RESET);
}

static void poll_console()
{
    uint8_t byte = 0;
    while (dbg_uart.read(&byte, 1) == 1)
    {
        if (bridge.passthrough())
        {
            if (byte == 'e')
            {
                bridge.set_passthrough(false);
                printf("\r\n%sExited passthrough mode.%s\r\n", CLR_TITLE, CLR_RESET);
                show_menu();
                return;
            }
            modem.at().uart().write(&byte, 1);
            continue;
        }

        if (byte == '\r' || byte == '\n')
        {
            if (cmd_idx > 0)
            {
                cmd_line[cmd_idx] = '\0';
                print("\r\n");
                process_cmd(cmd_line);
                cmd_idx = 0;
            }
            else
            {
                printf("\r\n%sgsm>%s ", CLR_PROMPT, CLR_RESET);
            }
        }
        else if (byte == 0x08 || byte == 0x7F)
        {
            if (cmd_idx > 0)
            {
                --cmd_idx;
                print("\b \b");
            }
        }
        else if (byte >= 0x20 && cmd_idx + 1 < sizeof(cmd_line))
        {
            cmd_line[cmd_idx++] = static_cast<char>(byte);
            dbg_uart.write(&byte, 1);
        }
    }
}
} // namespace cli

static void on_sms(void*, const SmsMessage& msg)
{
    cli::printf("\r\n%s[SMS RECEIVED]%s Slot: %d | From: %s%s%s | Time: %s\r\n", cli::CLR_VAL,
                cli::CLR_RESET, msg.storage_index, cli::CLR_KEY, msg.number.c_str(), cli::CLR_RESET,
                msg.timestamp.c_str());
    cli::printf("Content: %s%s%s\r\n", cli::CLR_TITLE, msg.text.c_str(), cli::CLR_RESET);
    cli::printf("%sgsm>%s ", cli::CLR_PROMPT, cli::CLR_RESET);

    if (msg.text.equals("ping"))
    {
        app_log.info("Auto-replying to ping with پونگ...");
        modem.send_sms(msg.number.c_str(), "پونگ");
    }
}

static void on_call(void*, CallState state, const char* peer)
{
    cli::printf("\r\n%s[CALL STATE]%s State: %s%s%s | Peer: %s%s%s\r\n", cli::CLR_VAL,
                cli::CLR_RESET, cli::CLR_KEY, to_string(state), cli::CLR_RESET, cli::CLR_KEY,
                peer ? peer : "none", cli::CLR_RESET);
    cli::printf("%sgsm>%s ", cli::CLR_PROMPT, cli::CLR_RESET);
}

static void on_sim_event(void*, SimState state)
{
    if (state == SimState::Removed)
    {
        cli::printf("\r\n%s[CRITICAL ALERT] SIM CARD WAS REMOVED!%s\r\n", cli::CLR_ERR,
                    cli::CLR_RESET);
    }
    else if (state == SimState::Ready)
    {
        cli::printf("\r\n%s[SIM ALERT] SIM Card is Inserted & Ready.%s\r\n", cli::CLR_VAL,
                    cli::CLR_RESET);
    }
    cli::printf("%sgsm>%s ", cli::CLR_PROMPT, cli::CLR_RESET);
}

static void on_job(void*, const Job& job)
{
    cli::printf("\r\n%s[JOB #%u FINISHED]%s Type: %s | State: %s%s%s (Ref: %d, Code: %d)\r\n",
                cli::CLR_TITLE, job.id, cli::CLR_RESET, to_string(job.kind),
                job.state == JobState::Succeeded ? cli::CLR_VAL : cli::CLR_ERR,
                to_string(job.state), cli::CLR_RESET, job.reference, job.result.code);
    if (job.kind == JobKind::UssdQuery && job.state == JobState::Succeeded)
    {
        cli::printf("%s[USSD RESPONSE]%s %s\r\n", cli::CLR_VAL, cli::CLR_RESET,
                    job.ussd_response.c_str());
    }
    cli::printf("%sgsm>%s ", cli::CLR_PROMPT, cli::CLR_RESET);
}

extern "C" int AppInit()
{
    log::Registry::set_sink(&log::writer_sink, &dbg_sink);
    log::Registry::set_color(true);
    log::Registry::set_timestamps(true);
    log::Registry::set_global_level(log::Level::Info);

    gsm_uart.begin();
    dbg_uart.begin();

    modem.set_on_sms(SmsService::Received(&on_sms, nullptr));
    modem.set_on_call(CallService::StateChanged(&on_call, nullptr));
    modem.set_on_sim(Modem::SimEventCb(&on_sim_event, nullptr));
    modem.set_on_job(JobCallback(&on_job, nullptr));

    modem.housekeeping().signal_ms     = 15000;
    modem.housekeeping().sms_scan_ms   = 20000;
    modem.housekeeping().full_sweep_ms = 60000;
    modem.housekeeping().cleanup_ms    = 300000;

    modem.begin();
    cli::print("\033[2J\033[H");
    cli::show_menu();
    return 0;
}

extern "C" int AppRun()
{
    if (!bridge.passthrough()) { modem.tick(); }
    cli::poll_console();
    return 0;
}

extern "C" void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef* huart, uint16_t size)
{
    if (huart->Instance == UART7)
        gsm_uart.on_rx_event(size);
    else if (huart->Instance == USART1)
        dbg_uart.on_rx_event(size);
}

extern "C" void HAL_UART_ErrorCallback(UART_HandleTypeDef* huart)
{
    if (huart->Instance == UART7)
        gsm_uart.on_error();
    else if (huart->Instance == USART1)
        dbg_uart.on_error();
}
