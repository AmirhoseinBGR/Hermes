# معماری کتابخانه GSM (SIM800 / Quectel M08)

هدف: یک درایور غیرمسدودکننده (non-blocking) با `tick()`، ماشین‌حالت اصلی + زیرحالت،
صف کار، و پیش‌فرض «SMS فارسی در Text Mode با UCS2». بدون STL، بدون heap،
بدون exception/RTTI.

## ۱) لایه‌بندی

```
L4  app                      ← کد شما (فقط با Modem حرف می‌زند)
--------------------------------------------------------------
L3  Modem                    main FSM + JobQueue + Housekeeping
    ├── SmsService           زیرحالت ارسال/خواندن/حذف
    ├── CallService          زیرحالت تماس + CallState
    └── StatusService        CSQ / CREG / CPIN / CPMS / COPS
--------------------------------------------------------------
L2  AtEngine                 یک فرمان در پرواز، تایم‌اوت، prompt، ESC
    ├── LineReader           بایت → خط (و تشخیص «> » بدون terminator)
    └── UrcRouter            RING / +CMTI / NO CARRIER / ...
--------------------------------------------------------------
L1  codec (UCS2, PhoneNumber) + log + util (StaticString, RingBuffer, Delegate)
--------------------------------------------------------------
L0  hal::IUart / IClock / IPowerControl   ← تنها نقطه‌ی وابستگی به پلتفرم
    ports/stm32 (پیش‌فرض) · ports/arduino · ports/host (تست دسکتاپ)
```

قاعده‌ی طلایی: **هیچ لایه‌ای به لایه‌ی بالاتر وابسته نیست** و فقط `AtEngine` با UART حرف می‌زند.
پورت جدید = پیاده‌سازی سه اینترفیس L0. ماژول جدید = یک `DeviceTraits` جدید.

## ۲) ماشین‌حالت

حالت اصلی (`ModemState`):

| حالت | معنی | خروج |
|---|---|---|
| `Off` | خاموش/شروع‌نشده | `begin()` |
| `Booting` | ارسال `AT` تا جواب دادن ماژول (۱۰ تلاش) | پاسخ `OK` |
| `Configuring` | اجرای لیست bootstrap (ATE0, CMEE, CLIP, CNMI, CMGF, CSCS, CSMP, CPMS) | پایان لیست |
| `Ready` | بی‌کار؛ فقط اینجا housekeeping اجرا می‌شود | آمدن Job یا URC |
| `Working` | یک Job در جریان است (`activity()` + `step()`) | پایان Job |
| `Ringing` | تماس ورودی در انتظار | `answer()` / `hang_up()` / `NO CARRIER` |
| `InCall` | تماس برقرار | قطع تماس |
| `Fault` | تسلیم؛ نیاز به `reset()` | `reset()` |

زیرحالت‌ها داخل سرویس‌ها زندگی می‌کنند (`SmsStep`, `CallStep`, `StatusStep`, `CallState`).
مثلاً ارسال پیامک: `cmgf → cscs → csmp → cpms → cmgs-header → payload → wait-cmgs`.
قدم‌های کانفیگ اگر قبلاً اعمال شده باشند (`SessionState`) بدون ترافیک AT رد می‌شوند؛
یعنی پیامک دوم فقط `AT+CMGS` می‌فرستد. هر خطا `SessionState` را بی‌اعتبار می‌کند تا
دفعه‌ی بعد کانفیگ از نو اعمال شود.

## ۳) صف کار (JobQueue)

- ظرفیت ثابت `GSM_QUEUE_DEPTH` (پیش‌فرض ۶)، FIFO، بدون allocation.
- `urgent` (مثل `hang_up()` و `answer()`) از جلوی صف وارد می‌شود.
- retry داخلی هر Job (`max_attempts`؛ ارسال پیامک پیش‌فرض ۲).
- کنترل کلی: `pause_queue()` / `resume_queue()` / `stop_all()` / `cancel(id)`.
  `stop_all()` هم Job در حال اجرا را با ESC/ATH می‌بندد، هم بقیه را Cancelled می‌کند
  و کالبک‌ها را صدا می‌زند (هیچ Job بی‌جواب نمی‌ماند).
- وضعیت صف قابل مشاهده است: `queue_size()`, `queued(i)`, `current_job()`.

## ۴) حالت Idle / نگهبانی

در `Ready` و طبق `HousekeepingConfig`:
`signal_ms` (CSQ) · `full_sweep_ms` (CSQ+CREG+CPIN+CPMS+COPS) · `sms_scan_ms`
(`AT+CMGL="REC UNREAD"` و تحویل + حذف) · `cleanup_ms` (`AT+CMGD=1,1` پاک‌سازی خوانده‌شده‌ها).
همه‌چیز در `ModemStatus` ذخیره می‌شود (`csq_raw`, `rssi_dbm`, `signal_bars()`,
`registration`, `sim_ready`, `sms_used/total`, `operator_name`).

## ۵) پیامک فارسی (پیش‌فرض کل سیستم)

`SmsEncoding::Ucs2` پیش‌فرض است. جزئیات کشف‌شده از لاگ‌های خودت در
[`QUIRKS.md`](QUIRKS.md) کد شده‌اند. خلاصه: در `CSCS="UCS2"` هم متن **و هم شماره**
باید UCS2-hex باشند و بعد از payload هیچ CRLF قبل از Ctrl+Z نباید برود.

## ۶) لاگ

`gsm::log` جانشین `def::debug` است: سطح Off..Trace، sink قابل تعویض (stdio / writer /
null)، **رنگ ANSI به‌صورت runtime قابل خاموش‌شدن**، timestamp، `bytes()` برای دیدن
`\r\n`/`<CtrlZ>`/`<ESC>` و `hexdump()`، حذف کامل در کامپایل با `GSM_LOG_LEVEL_MAX`.

## ۷) مصرف حافظه (پیش‌فرض)

RX ring 512B + DMA 256B + صف (۶ × ~۲۳۰B) + inbox/بافرهای متن ≈ **۳ تا ۴ کیلوبایت RAM**،
همه استاتیک. با `GSM_*` قابل کوچک‌شدن است.

## ۸) نقطه‌های توسعه (بدون دست‌زدن به هسته)

- ماژول جدید (M66، A6، SIM7600): یک `DeviceTraits` اضافه کن.
- GPRS/TCP بعداً: `net/DataService : IService` + `JobKind::*` جدید. هسته دست‌نخورده می‌ماند.
- PDU mode: `codec/pdu.*` + یک `SmsEncoding::Pdu`.
- USSD / تماس چندطرفه / AT+CLCC polling: سرویس جدید در همان الگو.
