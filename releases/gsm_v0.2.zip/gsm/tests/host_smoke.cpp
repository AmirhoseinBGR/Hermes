#include "gsm/codec/ucs2.hpp"
#include "gsm/modem/modem.hpp"
#include "gsm_port_host.hpp"
#include <cassert>
#include <cstdio>
#include <cstring>

using namespace gsm;

static port::HostUart<2048>   uart;
static port::HostClock        clock_;
static port::HostPowerControl pwr;
static Modem                  modem(uart, clock_, kSim800, &pwr);

static void advance(uint32_t ms, uint8_t rounds = 4)
{
    for (uint8_t i = 0; i < rounds; ++i)
    {
        clock_.now += ms;
        modem.tick();
    }
}

static bool tx_has(const char* needle)
{ return std::strstr(uart.tx(), needle); }

int main()
{
    char hex[128];
    assert(codec::utf8_to_ucs2_hex("سلام", hex, sizeof(hex)) == 16);
    assert(std::strcmp(hex, "0633064406270645") == 0);

    // Test operator detection
    assert(detect_operator("IRANCELL") == Operator::Irancell);
    assert(detect_operator("MTN Irancell") == Operator::Irancell);
    assert(detect_operator("IR-MCI") == Operator::Mci);
    assert(detect_operator("RighTel") == Operator::Rightel);

    // Test USSD default balance codes
    assert(std::strcmp(UssdService::default_balance_code(Operator::Irancell), "*141*1#") == 0);
    assert(std::strcmp(UssdService::default_balance_code(Operator::Mci), "*140*11#") == 0);
    assert(std::strcmp(UssdService::default_balance_code(Operator::Rightel), "*140#") == 0);

    printf("Testing boot sequence...\n");
    modem.begin();
    advance(50, 1);
    assert(tx_has("AT"));
    // Answer initial AT
    uart.inject("OK\r\n");
    advance(50, 2);
    assert(modem.state() == ModemState::WaitingRegistration);

    // Wait for registration
    uart.clear_tx();
    advance(100, 2);
    // Inject registration success (+CREG: 0,1)
    uart.inject("\r\n+CREG: 0,1\r\n\r\nOK\r\n");
    advance(50, 2);

    // Answer bootstrap commands
    for (int i = 0; i < 10; ++i)
    {
        advance(40, 1);
        uart.inject("OK\r\n");
        advance(40, 1);
    }
    printf("State after bootstrap: %s\n", modem.state_name());
    assert(modem.ready());

    // Test USSD query
    uart.clear_tx();
    JobId ussd_job = modem.check_balance();
    assert(ussd_job != kInvalidJob);
    advance(40, 2);
    assert(tx_has("AT+CUSD=1"));
    uart.inject("OK\r\n");
    advance(40, 2);
    // Simulate +CUSD response
    uart.inject("\r\n+CUSD: 0,\"Mojoodi: 50000 Rials\",15\r\n\r\nOK\r\n");
    advance(40, 3);
    assert(modem.current_job().kind == JobKind::None);
    printf("USSD response received successfully!\n");

    // Test SIM removal URC
    bool sim_removed_detected = false;
    modem.set_on_sim(Modem::SimEventCb(
        [](void* ctx, SimState s) {
            if (s == SimState::Removed) *static_cast<bool*>(ctx) = true;
        },
        &sim_removed_detected));

    uart.inject("\r\n+CPIN: NOT INSERTED\r\n");
    advance(40, 2);
    assert(modem.state() == ModemState::SimMissing);
    assert(sim_removed_detected);
    printf("SIM removal detected!\n");

    // Test SIM insertion URC
    uart.inject("\r\n+CPIN: READY\r\n");
    advance(40, 2);
    assert(modem.state() == ModemState::WaitingRegistration);
    printf("SIM re-insertion handled, waiting for registration!\n");

    printf("ALL TESTS PASSED!\n");
    return 0;
}
