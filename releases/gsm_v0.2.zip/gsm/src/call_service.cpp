#include "gsm/voice/call_service.hpp"
#include "gsm/log/log.hpp"
#include <cstdio>

namespace gsm
{

static const log::Channel kLog{"call", log::Level::Debug};

const char* to_string(CallState s)
{
    switch (s)
    {
    case CallState::Idle:
        return "idle";
    case CallState::Dialing:
        return "dialing";
    case CallState::Outgoing:
        return "outgoing";
    case CallState::Incoming:
        return "incoming";
    case CallState::Active:
        return "active";
    case CallState::Releasing:
        return "releasing";
    }
    return "?";
}

const char* to_string(CallStep s)
{
    switch (s)
    {
    case CallStep::Idle:
        return "idle";
    case CallStep::EnableClip:
        return "clip";
    case CallStep::Dial:
        return "atd";
    case CallStep::Answer:
        return "ata";
    case CallStep::Hangup:
        return "ath";
    case CallStep::Done:
        return "done";
    }
    return "?";
}

void CallService::set_state(CallState s)
{
    if (state_ == s) return;
    state_ = s;
    kLog.info("state=%s peer=%s", to_string(s), peer_.e164());
    if (on_state_) on_state_(s, peer_.e164());
}

bool CallService::start_dial(const char* number)
{
    if (active() || state_ != CallState::Idle) return false;
    if (!peer_.assign(number)) return false;
    result_ = AtResult{};
    step_   = (auto_clip_ && !clip_enabled_) ? CallStep::EnableClip : CallStep::Dial;
    issued_ = false;
    set_state(CallState::Dialing);
    return true;
}

bool CallService::start_answer()
{
    if (active() || state_ != CallState::Incoming) return false;
    result_ = AtResult{};
    step_   = CallStep::Answer;
    issued_ = false;
    return true;
}

bool CallService::start_hangup()
{
    if (active() && step_ != CallStep::Hangup) at_.abort();
    result_ = AtResult{};
    step_   = CallStep::Hangup;
    issued_ = false;
    set_state(CallState::Releasing);
    return true;
}

void CallService::cancel()
{
    if (state_ == CallState::Idle)
    {
        step_ = CallStep::Idle;
        return;
    }
    start_hangup();
}

void CallService::pump()
{
    if (!active() || issued_) return;
    char cmd[GSM_CMD_MAX];
    switch (step_)
    {
    case CallStep::EnableClip:
        issued_ = at_.execute("AT+CLIP=1", 1000, this);
        return;
    case CallStep::Dial:
        std::snprintf(cmd, sizeof(cmd), "ATD%s;", peer_.e164());
        issued_ = at_.execute(cmd, 20000, this);
        return;
    case CallStep::Answer:
        issued_ = at_.execute("ATA", 20000, this);
        return;
    case CallStep::Hangup:
        issued_ = at_.execute(traits_.hangup_cmd, 5000, this);
        return;
    default:
        return;
    }
}

void CallService::on_line(const char* line, uint16_t len)
{
    (void)line;
    (void)len;
}

void CallService::finish(AtStatus st, int16_t code)
{
    result_ = AtResult{st, code};
    step_   = CallStep::Idle;
    issued_ = false;
}

void CallService::on_final(const AtResult& res)
{
    issued_ = false;
    switch (step_)
    {
    case CallStep::EnableClip:
        clip_enabled_ = res.ok();
        step_         = CallStep::Dial;
        return;
    case CallStep::Dial:
        if (res.ok())
        {
            set_state(CallState::Outgoing);
            finish(AtStatus::Ok, -1);
        }
        else
        {
            set_state(CallState::Idle);
            finish(res.status, res.code);
        }
        return;
    case CallStep::Answer:
        if (res.ok())
            set_state(CallState::Active);
        else
            set_state(CallState::Idle);
        finish(res.status, res.code);
        return;
    case CallStep::Hangup:
        peer_.clear();
        set_state(CallState::Idle);
        finish(res.status, res.code);
        return;
    default:
        finish(res.status, res.code);
        return;
    }
}

void CallService::notify_ring(const char* caller)
{
    if (caller && *caller) peer_.assign(caller);
    if (state_ == CallState::Idle) set_state(CallState::Incoming);
}

void CallService::notify_hangup()
{
    peer_.clear();
    step_   = CallStep::Idle;
    issued_ = false;
    set_state(CallState::Idle);
}

void CallService::notify_busy()
{
    set_state(CallState::Idle);
    step_ = CallStep::Idle;
}

} // namespace gsm
