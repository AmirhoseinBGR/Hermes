#pragma once
#include "gsm/codec/phone_number.hpp"
#include "gsm/core/service.hpp"
#include "gsm/device/device_traits.hpp"
#include "gsm/util/delegate.hpp"

namespace gsm {

enum class CallState : uint8_t {
  Idle = 0, Dialing, Outgoing, Incoming, Active, Releasing
};

enum class CallStep : uint8_t { Idle = 0, EnableClip, Dial, Answer, Hangup, Done };

const char *to_string(CallState s);
const char *to_string(CallStep s);

class CallService final : public IService {
public:
  using StateChanged = Delegate<CallState, const char *>;

  CallService(AtEngine &engine, SessionState &session, const DeviceTraits &traits)
      : at_(engine), session_(session), traits_(traits) {}

  bool start_dial(const char *number_e164);
  bool start_answer();
  bool start_hangup();

  bool active() const override { return step_ != CallStep::Idle; }
  void pump() override;
  void cancel() override;
  const char *step_name() const override { return to_string(step_); }
  const AtResult &result() const override { return result_; }
  void on_line(const char *line, uint16_t len) override;
  void on_final(const AtResult &res) override;

  void notify_ring(const char *caller);
  void notify_hangup();
  void notify_busy();

  CallState state() const { return state_; }
  const char *peer() const { return peer_.e164(); }
  bool in_call() const { return state_ == CallState::Active; }
  bool ringing() const { return state_ == CallState::Incoming; }
  void set_on_state(StateChanged cb) { on_state_ = cb; }
  void set_auto_clip(bool on) { auto_clip_ = on; }

private:
  void set_state(CallState s);
  void finish(AtStatus st, int16_t code);

  AtEngine &at_;
  SessionState &session_;
  const DeviceTraits &traits_;
  CallStep step_ = CallStep::Idle;
  bool issued_ = false;
  bool clip_enabled_ = false;
  bool auto_clip_ = true;
  CallState state_ = CallState::Idle;
  PhoneNumber peer_;
  AtResult result_;
  StateChanged on_state_;
};

} // namespace gsm
