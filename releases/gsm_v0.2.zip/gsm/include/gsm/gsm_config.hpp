#pragma once

#if defined(GSM_USER_CONFIG)
#include GSM_USER_CONFIG
#endif

// --- buffers -----------------------------------------------------------------
#ifndef GSM_RX_RING_SIZE
#define GSM_RX_RING_SIZE 1024
#endif
#ifndef GSM_LINE_MAX
#define GSM_LINE_MAX 512
#endif
#ifndef GSM_CMD_MAX
#define GSM_CMD_MAX 256
#endif

// --- sms & ussd --------------------------------------------------------------
#ifndef GSM_SMS_TEXT_BYTES
#define GSM_SMS_TEXT_BYTES 512
#endif
#ifndef GSM_SMS_NUMBER_BYTES
#define GSM_SMS_NUMBER_BYTES 24
#endif
#ifndef GSM_SMS_INBOX_SLOTS
#define GSM_SMS_INBOX_SLOTS 4
#endif
#ifndef GSM_USSD_RESPONSE_BYTES
#define GSM_USSD_RESPONSE_BYTES 512
#endif

// --- queue -------------------------------------------------------------------
#ifndef GSM_QUEUE_DEPTH
#define GSM_QUEUE_DEPTH 6
#endif

// --- timing (ms) -------------------------------------------------------------
#ifndef GSM_AT_DEFAULT_TIMEOUT
#define GSM_AT_DEFAULT_TIMEOUT 1000
#endif
#ifndef GSM_AT_PROMPT_TIMEOUT
#define GSM_AT_PROMPT_TIMEOUT 5000
#endif
#ifndef GSM_AT_CMGS_TIMEOUT
#define GSM_AT_CMGS_TIMEOUT 10000
#endif
#ifndef GSM_AT_USSD_TIMEOUT
#define GSM_AT_USSD_TIMEOUT 10000
#endif
#ifndef GSM_AT_GUARD_TIME
#define GSM_AT_GUARD_TIME 30
#endif
#ifndef GSM_REGISTRATION_TIMEOUT
#define GSM_REGISTRATION_TIMEOUT 45000
#endif
#ifndef GSM_PWRKEY_PULSE_MS
#define GSM_PWRKEY_PULSE_MS 500
#endif

// --- logging -----------------------------------------------------------------
#ifndef GSM_LOG_LEVEL_MAX
#define GSM_LOG_LEVEL_MAX 4 // 0=off 1=err 2=warn 3=info 4=debug 5=trace
#endif
#ifndef GSM_LOG_BUFFER_SIZE
#define GSM_LOG_BUFFER_SIZE 180
#endif
#ifndef GSM_LOG_COLOR_DEFAULT
#define GSM_LOG_COLOR_DEFAULT 1
#endif
