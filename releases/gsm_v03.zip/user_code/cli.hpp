#pragma once

#include "main.h"

namespace cli
{

// Initialize CLI subsystem (hardware, modem, callbacks)
void init();

// Process one CLI tick (call from main loop)
void tick();

// HAL UART event handlers
void on_uart_rx(UART_HandleTypeDef* huart, uint16_t size);
void on_uart_error(UART_HandleTypeDef* huart);

} // namespace cli
