#include "cli.hpp"
#include "app.hpp"
#include "gsm/modem/modem.hpp"
#include "gsm/ports/stm32/gsm_port_stm32.hpp"
#include "gsm/tools/serial_bridge.hpp"
#include "usart.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>

using namespace gsm;

namespace cli
{

static void draw_live_status();

// ============ Hardware instances ============
static port::Stm32Uart<512>    s_gsm_uart(&huart7);
static port::Stm32Uart<256>    s_dbg_uart(&huart1);
static port::Stm32Clock        s_clk;
// PWRKEY pin: Optional hardware control (GSM_PWR_GPIO_Port, GSM_PWR_Pin from main.h)
#if defined(GSM_PWR_GPIO_Port) && defined(GSM_PWR_Pin)
static port::Stm32PowerControl s_gsmpwr(GSM_PWR_GPIO_Port, GSM_PWR_Pin);
static Modem                   s_modem(s_gsm_uart, s_clk, kQuectelM08, &s_gsmpwr);
#else
static Modem                   s_modem(s_gsm_uart, s_clk, kQuectelM08, nullptr);
#endif

static tools::SerialBridge     s_bridge(s_dbg_uart, s_modem);
static log::Channel            s_log{"cli", log::Level::Trace};

// ============ CLI state ============
enum class Mode : uint8_t
{
    Menu,
    LiveStatus,
    Passthrough
};

static Mode               s_mode = Mode::Menu;
static char               s_line[128];
static uint16_t           s_line_idx  = 0;
static uint32_t           s_last_draw = 0;
static constexpr uint32_t kRefreshMs  = 2000;

// ============ ANSI helpers ============
namespace ansi
{
constexpr const char* RST       = "\033[0m";
constexpr const char* BOLD      = "\033[1m";
constexpr const char* DIM       = "\033[2m";
constexpr const char* RED       = "\033[31m";
constexpr const char* GREEN     = "\033[32m";
constexpr const char* YELLOW    = "\033[33m";
constexpr const char* BLUE      = "\033[34m";
constexpr const char* MAGENTA   = "\033[35m";
constexpr const char* CYAN      = "\033[36m";
constexpr const char* WHITE     = "\033[37m";
constexpr const char* B_RED     = "\033[1;31m";
constexpr const char* B_GREEN   = "\033[1;32m";
constexpr const char* B_YELLOW  = "\033[1;33m";
constexpr const char* B_BLUE    = "\033[1;34m";
constexpr const char* B_MAGENTA = "\033[1;35m";
constexpr const char* B_CYAN    = "\033[1;36m";
constexpr const char* B_WHITE   = "\033[1;37m";
constexpr const char* CLR       = "\033[2J";
constexpr const char* HOME      = "\033[H";

void put(const char* s)
{
    if (s)
        s_dbg_uart.write(reinterpret_cast<const uint8_t*>(s),
                         static_cast<uint16_t>(std::strlen(s)));
}

void clear()
{
    put(CLR);
    put(HOME);
}

void bar(int pct, int w)
{
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    const int   n   = (pct * w) / 100;
    const char* col = (pct < 30) ? B_RED : (pct < 60 ? B_YELLOW : B_GREEN);
    put(col);
    for (int i = 0; i < w; ++i)
    {
        if (i < n)
            put("#");
        else
        {
            put(DIM);
            put(".");
            put(RST);
            put(col);
        }
    }
    put(RST);
}

void divider()
{
    put(DIM);
    put("  --------------------------------------------------------\r\n");
    put(RST);
}
} // namespace ansi

static const char* lvl_name(log::Level l)
{
    switch (l)
    {
    case log::Level::Trace: return "TRACE";
    case log::Level::Debug: return "DEBUG";
    case log::Level::Info:  return "INFO";
    case log::Level::Warn:  return "WARN";
    case log::Level::Error: return "ERROR";
    default:                return "?";
    }
}
static const char* lvl_color(log::Level l)
{
    switch (l)
    {
    case log::Level::Trace: return ansi::DIM;
    case log::Level::Debug: return ansi::CYAN;
    case log::Level::Info:  return ansi::B_GREEN;
    case log::Level::Warn:  return ansi::B_YELLOW;
    case log::Level::Error: return ansi::B_RED;
    default:                return ansi::WHITE;
    }
}
static void cycle_level()
{
    log::Level l = log::Registry::global_level();
    switch (l)
    {
    case log::Level::Trace: l = log::Level::Debug; break;
    case log::Level::Debug: l = log::Level::Info;  break;
    case log::Level::Info:  l = log::Level::Warn;  break;
    case log::Level::Warn:  l = log::Level::Error; break;
    case log::Level::Error: l = log::Level::Trace; break;
    default:                l = log::Level::Info;  break;
    }
    log::Registry::set_global_level(l);
}

static void prompt()
{
    ansi::put(ansi::B_BLUE);
    ansi::put("gsm> ");
    ansi::put(ansi::RST);
}

static void redraw_current()
{
    if (s_mode == Mode::LiveStatus)
    {
        ansi::put("\r\n");
        draw_live_status();
    }
    else
    {
        prompt();
    }
}

static void draw_status_bar()
{
    const auto& st = s_modem.status();
    char        buf[48];

    ansi::put("  ");

    if (st.network_ready)
    {
        ansi::put(ansi::B_GREEN);
        ansi::put("NET");
        ansi::put(ansi::RST);
        ansi::put(":");
        ansi::put(st.operator_name.empty() ? "?" : st.operator_name.c_str());
    }
    else
    {
        ansi::put(ansi::B_RED);
        ansi::put("NET:--");
        ansi::put(ansi::RST);
    }

    ansi::put("  ");

    ansi::put(ansi::B_WHITE);
    ansi::put("SIG");
    ansi::put(ansi::RST);
    ansi::put(":");
    std::snprintf(buf, sizeof(buf), "%ddBm[%d/5]", st.rssi_dbm, st.signal_bars());
    ansi::put(buf);

    ansi::put("  ");

    ansi::put(st.sim_ready ? ansi::B_GREEN : ansi::B_RED);
    ansi::put(st.sim_ready ? "SIM:OK" : "SIM:--");
    ansi::put(ansi::RST);

    ansi::put("  ");

    ansi::put(ansi::B_WHITE);
    ansi::put("SMS");
    ansi::put(ansi::RST);
    ansi::put(":");
    std::snprintf(buf, sizeof(buf), "%u/%u", st.sms_used, st.sms_total);
    ansi::put(buf);

    ansi::put("  ");

    const bool paused = s_modem.queue_paused();
    ansi::put(paused ? ansi::B_YELLOW : ansi::B_GREEN);
    std::snprintf(buf, sizeof(buf), "Q:%s%u/%u", paused ? "!" : "", s_modem.queue_size(),
                  JobQueue::capacity());
    ansi::put(buf);
    ansi::put(ansi::RST);

    ansi::put("  ");

    const char* cstate = to_string(s_modem.call().state());
    if (std::strcmp(cstate, "idle") != 0)
    {
        ansi::put(ansi::B_YELLOW);
        ansi::put("CALL:");
        ansi::put(cstate);
        ansi::put(ansi::RST);
        ansi::put("  ");
    }

    ansi::put(ansi::DIM);
    ansi::put("FSM:");
    ansi::put(s_modem.state_name());
    ansi::put(ansi::RST);

    ansi::put("\r\n");
}

static void kv(const char* key, const char* val, const char* vcol)
{
    ansi::put("  ");
    ansi::put(ansi::B_WHITE);
    ansi::put(key);
    ansi::put(ansi::RST);
    const int klen = (int)std::strlen(key);
    for (int i = klen; i < 14; ++i)
        ansi::put(" ");
    ansi::put(" : ");
    ansi::put(vcol);
    ansi::put(val);
    ansi::put(ansi::RST);
    ansi::put("\r\n");
}

static void draw_live_status()
{
    ansi::clear();
    const auto& st = s_modem.status();

    ansi::put("\r\n  ");
    ansi::put(ansi::B_MAGENTA);
    ansi::put("◉ LIVE MODEM STATUS");
    ansi::put(ansi::DIM);
    ansi::put("  (ESC to exit, type commands below)");
    ansi::put(ansi::RST);
    ansi::put("\r\n");
    ansi::divider();

    char buf[96];
    std::snprintf(buf, sizeof(buf), "%s (%s/%s)", s_modem.state_name(), s_modem.activity(),
                  s_modem.step());
    kv("FSM", buf, s_modem.ready() ? ansi::B_GREEN : ansi::B_YELLOW);

    const int bars = st.signal_bars();
    const int pct  = (bars * 100) / 5;
    ansi::put("  ");
    ansi::put(ansi::B_WHITE);
    ansi::put("Signal");
    for (int i = 6; i < 14; ++i)
        ansi::put(" ");
    ansi::put(ansi::RST);
    ansi::put(" : ");
    ansi::bar(pct, 20);
    std::snprintf(buf, sizeof(buf), "  %3ddBm [%d/5]", st.rssi_dbm, bars);
    ansi::put(buf);
    ansi::put("\r\n");

    if (st.network_ready)
    {
        std::snprintf(buf, sizeof(buf), "REGISTERED (%s)", to_string(st.registration));
        kv("Network", buf, ansi::B_GREEN);
    }
    else
    {
        kv("Network", "NO SIGNAL / NOT REGISTERED", ansi::B_RED);
    }

    kv("Operator", st.operator_name.empty() ? "N/A" : st.operator_name.c_str(), ansi::B_CYAN);

    kv("SIM", st.sim_ready ? "READY" : to_string(st.sim_state),
       st.sim_ready ? ansi::B_GREEN : ansi::B_RED);

    const int spct = st.sms_total ? (st.sms_used * 100) / st.sms_total : 0;
    ansi::put("  ");
    ansi::put(ansi::B_WHITE);
    ansi::put("SMS Storage");
    ansi::put(ansi::RST);
    ansi::put(" : ");
    ansi::bar(spct, 20);
    std::snprintf(buf, sizeof(buf), "  %u/%u msgs", st.sms_used, st.sms_total);
    ansi::put(buf);
    ansi::put("\r\n");

    const auto* peer = s_modem.call().peer();
    if (peer && *peer)
    {
        std::snprintf(buf, sizeof(buf), "%s -> %s", to_string(s_modem.call().state()), peer);
        kv("Call", buf, ansi::B_YELLOW);
    }
    else
    {
        kv("Call", to_string(s_modem.call().state()), ansi::DIM);
    }

    std::snprintf(buf, sizeof(buf), "%s (%u/%u)", s_modem.queue_paused() ? "PAUSED" : "ACTIVE",
                  s_modem.queue_size(), JobQueue::capacity());
    kv("Queue", buf, s_modem.queue_paused() ? ansi::B_YELLOW : ansi::B_GREEN);

    const uint32_t age = st.updated_at_ms ? (s_clk.millis() - st.updated_at_ms) : 0;
    if (age < 1000)
        std::snprintf(buf, sizeof(buf), "%lu ms", (unsigned long)age);
    else
        std::snprintf(buf, sizeof(buf), "%lu.%01lu s", (unsigned long)(age / 1000),
                      (unsigned long)((age % 1000) / 100));
    kv("Updated", buf, ansi::DIM);

    ansi::divider();
    prompt();
}

static void draw_menu()
{
    ansi::clear();

    ansi::put("\r\n  ");
    ansi::put(ansi::B_MAGENTA);
    ansi::put("◉ GSM MODEM INDUSTRIAL CONSOLE ◉");
    ansi::put(ansi::RST);
    ansi::put("\r\n");

    draw_status_bar();
    ansi::divider();

    // Status & Info section
    ansi::put("  ");
    ansi::put(ansi::B_CYAN);
    ansi::put("[STATUS & INFO]");
    ansi::put(ansi::RST);
    ansi::put("\r\n");
    ansi::put("    ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("i");
    ansi::put(ansi::RST);
    ansi::put("  Live status (auto-refresh)     ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("s");
    ansi::put(ansi::RST);
    ansi::put("  Trigger sweep\r\n");
    ansi::put("    ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("q");
    ansi::put(ansi::RST);
    ansi::put("  Queue details                  ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("r");
    ansi::put(ansi::RST);
    ansi::put("  Scan unread SMS\r\n");
    ansi::put("    ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("d");
    ansi::put(ansi::RST);
    ansi::put("  Clean read SMS                 ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("b");
    ansi::put(ansi::RST);
    ansi::put("  SIM balance (USSD)\r\n");

    // Actions & Hardware Power section
    ansi::put("\r\n  ");
    ansi::put(ansi::B_GREEN);
    ansi::put("[ACTIONS & RECOVERY]");
    ansi::put(ansi::RST);
    ansi::put("\r\n");
    ansi::put("    ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("p");
    ansi::put(ansi::RST);
    ansi::put("  Pause/Resume queue             ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("x");
    ansi::put(ansi::RST);
    ansi::put("  Stop & clear queue\r\n");
    ansi::put("    ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("h");
    ansi::put(ansi::RST);
    ansi::put("  Urgent hangup                  ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("R");
    ansi::put(ansi::RST);
    ansi::put("  Reset FSM (Software)\r\n");
    ansi::put("    ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("K");
    ansi::put(ansi::RST);
    ansi::put("  Pulse PWRKEY (Hard Reset)      ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("P");
    ansi::put(ansi::RST);
    ansi::put("  Passthrough bridge\r\n");
    ansi::put("    ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("c");
    ansi::put(ansi::RST);
    ansi::put("  Clear screen\r\n");

    // Logging section
    ansi::put("\r\n  ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("[LOGGING]");
    ansi::put(ansi::RST);
    ansi::put("  level=");
    ansi::put(lvl_color(log::Registry::global_level()));
    ansi::put(lvl_name(log::Registry::global_level()));
    ansi::put(ansi::RST);
    ansi::put("\r\n");
    ansi::put("    ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("L");
    ansi::put(ansi::RST);
    ansi::put("  Cycle log level                ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("T");
    ansi::put(ansi::RST);
    ansi::put("  Toggle timestamps\r\n");
    ansi::put("    ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("C");
    ansi::put(ansi::RST);
    ansi::put("  Toggle ANSI colors\r\n");

    // Commands section
    ansi::put("\r\n  ");
    ansi::put(ansi::B_BLUE);
    ansi::put("[COMMANDS]");
    ansi::put(ansi::RST);
    ansi::put("\r\n");
    ansi::put("    ");
    ansi::put(ansi::DIM);
    ansi::put("sms <num> <text>    dial <num>    ussd <code>\r\n");
    ansi::put("    read <idx>          del <idx>     at <cmd>");
    ansi::put(ansi::RST);
    ansi::put("\r\n");

    ansi::divider();
    ansi::put("  ");
    ansi::put(ansi::B_YELLOW);
    ansi::put("m");
    ansi::put(ansi::RST);
    ansi::put(" - Reprint menu\r\n");
    ansi::put("  ");
    ansi::put(ansi::B_BLUE);
    ansi::put("gsm> ");
    ansi::put(ansi::RST);
}

static void draw_queue()
{
    ansi::clear();
    ansi::put("\r\n  ");
    ansi::put(ansi::B_MAGENTA);
    ansi::put("◉ QUEUE STATUS");
    ansi::put(ansi::DIM);
    ansi::put("  (press ESC to exit)");
    ansi::put(ansi::RST);
    ansi::put("\r\n");
    ansi::divider();

    const bool paused = s_modem.queue_paused();
    char       buf[64];
    std::snprintf(buf, sizeof(buf), "%s", paused ? "PAUSED" : "ACTIVE");
    kv("State", buf, paused ? ansi::B_RED : ansi::B_GREEN);

    std::snprintf(buf, sizeof(buf), "%u / %u", s_modem.queue_size(), JobQueue::capacity());
    kv("Size", buf, ansi::B_YELLOW);

    const auto& cur = s_modem.current_job();
    if (cur.kind != JobKind::None)
    {
        std::snprintf(buf, sizeof(buf), "#%u %s (try %u/%u)", cur.id, to_string(cur.kind),
                      cur.attempts, cur.max_attempts);
        kv("Current", buf, ansi::B_CYAN);
    }
    else
    {
        kv("Current", "(idle)", ansi::DIM);
    }

    ansi::put("\r\n  ");
    ansi::put(ansi::B_WHITE);
    ansi::put("Queued Jobs:");
    ansi::put(ansi::RST);
    ansi::put("\r\n");

    for (uint8_t i = 0; i < s_modem.queue_size(); ++i)
    {
        const auto* j = s_modem.queued(i);
        if (!j) continue;
        ansi::put("    [");
        ansi::put(ansi::DIM);
        char idx[8];
        std::snprintf(idx, sizeof(idx), "%u", i);
        ansi::put(idx);
        ansi::put(ansi::RST);
        ansi::put("] #");
        char id[8];
        std::snprintf(id, sizeof(id), "%u", j->id);
        ansi::put(id);
        ansi::put("  ");
        ansi::put(ansi::B_CYAN);
        ansi::put(to_string(j->kind));
        ansi::put(ansi::RST);
        if (j->urgent)
        {
            ansi::put("  ");
            ansi::put(ansi::B_RED);
            ansi::put("URGENT");
            ansi::put(ansi::RST);
        }
        ansi::put("\r\n");
    }

    ansi::divider();
    ansi::put("  ");
    ansi::put(ansi::B_BLUE);
    ansi::put("gsm> ");
    ansi::put(ansi::RST);
}

static void handle(char* line)
{
    while (*line == ' ')
        ++line;
    if (!*line)
    {
        redraw_current();
        return;
    }

    if (std::strcmp(line, "m") == 0)
    {
        s_mode = Mode::Menu;
        draw_menu();
        return;
    }
    if (std::strcmp(line, "c") == 0)
    {
        ansi::clear();
        s_mode = Mode::Menu;
        draw_menu();
        return;
    }
    if (std::strcmp(line, "i") == 0)
    {
        s_mode = Mode::LiveStatus;
        draw_live_status();
        return;
    }
    if (std::strcmp(line, "q") == 0)
    {
        draw_queue();
        return;
    }

    if (std::strcmp(line, "s") == 0)
    {
        printf("Triggering sweep...\r\n");
        s_modem.refresh_status();
        redraw_current();
        return;
    }
    if (std::strcmp(line, "r") == 0)
    {
        printf("Scanning SMS...\r\n");
        s_modem.scan_sms();
        redraw_current();
        return;
    }
    if (std::strcmp(line, "d") == 0)
    {
        printf("Deleting read SMS...\r\n");
        s_modem.delete_read_sms();
        redraw_current();
        return;
    }
    if (std::strcmp(line, "h") == 0)
    {
        printf("%sHangup queued.%s\r\n", ansi::B_YELLOW, ansi::RST);
        s_modem.hang_up();
        redraw_current();
        return;
    }
    if (std::strcmp(line, "b") == 0)
    {
        printf("Querying balance...\r\n");
        s_modem.check_balance();
        redraw_current();
        return;
    }
    if (std::strcmp(line, "p") == 0)
    {
        if (s_modem.queue_paused())
        {
            s_modem.resume_queue();
            printf("%sResumed.%s\r\n", ansi::B_GREEN, ansi::RST);
        }
        else
        {
            s_modem.pause_queue();
            printf("%sPaused.%s\r\n", ansi::B_YELLOW, ansi::RST);
        }
        redraw_current();
        return;
    }
    if (std::strcmp(line, "x") == 0)
    {
        printf("%sStopping all and clearing queue!%s\r\n", ansi::B_RED, ansi::RST);
        s_modem.stop_all(false);
        redraw_current();
        return;
    }
    if (std::strcmp(line, "R") == 0)
    {
        printf("%sSoftware reset of FSM...%s\r\n", ansi::B_YELLOW, ansi::RST);
        s_modem.reset();
        redraw_current();
        return;
    }
    if (std::strcmp(line, "K") == 0)
    {
        printf("%sHardware Power Cycle (PWRKEY)...%s\r\n", ansi::B_MAGENTA, ansi::RST);
        s_modem.power_cycle();
        redraw_current();
        return;
    }
    if (std::strcmp(line, "P") == 0)
    {
        const bool next = !s_bridge.passthrough();
        s_bridge.set_passthrough(next);
        if (next)
        {
            s_mode = Mode::Passthrough;
            printf("%sPassthrough ON%s (press 'e' to exit)\r\n", ansi::B_MAGENTA, ansi::RST);
        }
        else
        {
            s_mode = Mode::Menu;
            printf("%sPassthrough OFF%s\r\n", ansi::YELLOW, ansi::RST);
            draw_menu();
        }
        return;
    }

    if (std::strcmp(line, "L") == 0)
    {
        cycle_level();
        printf("Log level: %s%s%s\r\n", lvl_color(log::Registry::global_level()),
               lvl_name(log::Registry::global_level()), ansi::RST);
        redraw_current();
        return;
    }
    if (std::strcmp(line, "T") == 0)
    {
        const bool n = !log::Registry::timestamps();
        log::Registry::set_timestamps(n);
        printf("Timestamps %s\r\n", n ? "on" : "off");
        redraw_current();
        return;
    }
    if (std::strcmp(line, "C") == 0)
    {
        const bool n = !log::Registry::color();
        log::Registry::set_color(n);
        printf("ANSI %s\r\n", n ? "on" : "off");
        redraw_current();
        return;
    }

    if (std::strncmp(line, "sms ", 4) == 0)
    {
        char* p = line + 4;
        while (*p == ' ')
            ++p;
        char* num = p;
        char* sep = std::strchr(p, ' ');
        if (!sep)
        {
            printf("%sUsage: sms <num> <text>%s\r\n", ansi::B_RED, ansi::RST);
            redraw_current();
            return;
        }
        *sep       = '\0';
        char* text = sep + 1;
        while (*text == ' ')
            ++text;
        JobId id = s_modem.send_sms(num, text);
        if (id != kInvalidJob)
            printf("%sQueued SMS #%u to %s%s\r\n", ansi::B_GREEN, id, num, ansi::RST);
        else
            printf("%sQueue full%s\r\n", ansi::B_RED, ansi::RST);
        redraw_current();
        return;
    }
    if (std::strncmp(line, "dial ", 5) == 0)
    {
        char* num = line + 5;
        while (*num == ' ')
            ++num;
        JobId id = s_modem.dial(num);
        if (id != kInvalidJob)
            printf("%sDial #%u to %s%s\r\n", ansi::B_GREEN, id, num, ansi::RST);
        else
            printf("%sQueue full%s\r\n", ansi::B_RED, ansi::RST);
        redraw_current();
        return;
    }
    if (std::strncmp(line, "ussd ", 5) == 0)
    {
        char* code = line + 5;
        while (*code == ' ')
            ++code;
        JobId id = s_modem.ussd(code);
        printf("%sUSSD #%u (%s)%s\r\n", ansi::B_GREEN, id, code, ansi::RST);
        redraw_current();
        return;
    }
    if (std::strncmp(line, "read ", 5) == 0)
    {
        int idx = std::atoi(line + 5);
        s_modem.read_sms(static_cast<int16_t>(idx));
        printf("Read SMS idx=%d\r\n", idx);
        redraw_current();
        return;
    }
    if (std::strncmp(line, "del ", 4) == 0)
    {
        int idx = std::atoi(line + 4);
        s_modem.sms().start_delete_index(static_cast<int16_t>(idx));
        printf("Deleting idx=%d...\r\n", idx);
        redraw_current();
        return;
    }
    if (std::strncmp(line, "at ", 3) == 0)
    {
        char* at = line + 3;
        while (*at == ' ')
            ++at;
        if (s_modem.at().idle())
        {
            printf("Sending: %s\r\n", at);
            s_modem.at().execute(at, 5000, &s_bridge);
        }
        else
        {
            printf("%sAT engine busy!%s\r\n", ansi::B_RED, ansi::RST);
        }
        redraw_current();
        return;
    }

    printf("%sUnknown: %s%s (press 'm')\r\n", ansi::B_RED, line, ansi::RST);
    redraw_current();
}

static void on_sms(void*, const SmsMessage& msg)
{
    s_log.info("%s[SMS]%s [%d] from=%s%s%s\r\n", ansi::B_GREEN, ansi::RST, msg.storage_index,
               ansi::B_YELLOW, msg.number.c_str(), ansi::RST);
    s_log.info("  %s\r\n", msg.text.c_str());
    if (msg.text.equals("ping"))
    {
        s_log.info("Auto-reply 'pong'");
        s_modem.send_sms(msg.number.c_str(), "pong");
    }
    redraw_current();
}
static void on_call(void*, CallState state, const char* peer)
{
    s_log.warn("%s[CALL]%s %s%s%s peer=%s\r\n", ansi::B_YELLOW, ansi::RST, ansi::B_CYAN,
               to_string(state), ansi::RST, peer ? peer : "none");
    redraw_current();
}
static void on_sim_event(void*, SimState state)
{
    if (state == SimState::Removed)
        s_log.error("%s[!] CRITICAL: SIM CARD REMOVED!%s\r\n", ansi::B_RED, ansi::RST);
    else if (state == SimState::Ready)
        s_log.info("%s[SIM] SIM CARD READY%s\r\n", ansi::B_GREEN, ansi::RST);
    redraw_current();
}
static void on_job(void*, const Job& job)
{
    if (gsm::log::Registry::global_level() == log::Level::Trace ||
        gsm::log::Registry::global_level() == log::Level::Info)
    {
        printf("\r\n%s[JOB#%u]%s %s %s%s%s code=%d\r\n", ansi::B_MAGENTA, job.id, ansi::RST,
               to_string(job.kind), job.state == JobState::Succeeded ? ansi::B_GREEN : ansi::B_RED,
               to_string(job.state), ansi::RST, job.result.code);
        if (job.kind == JobKind::UssdQuery && job.state == JobState::Succeeded)
            printf("  USSD: %s\r\n", job.ussd_response.c_str());
        redraw_current();
    }
}

static void poll_input()
{
    uint8_t byte = 0;
    while (s_dbg_uart.read(&byte, 1) == 1)
    {
        if (s_mode == Mode::Passthrough)
        {
            if (byte == 'e')
            {
                s_bridge.set_passthrough(false);
                s_mode = Mode::Menu;
                printf("\r\n%sExited passthrough.%s\r\n", ansi::B_MAGENTA, ansi::RST);
                draw_menu();
                return;
            }
            s_modem.at().uart().write(&byte, 1);
            continue;
        }

        if (byte == 0x1B)
        {
            if (s_mode != Mode::Menu)
            {
                s_mode     = Mode::Menu;
                s_line_idx = 0;
                draw_menu();
            }
            continue;
        }

        if (byte == '\r' || byte == '\n')
        {
            if (s_line_idx > 0)
            {
                s_line[s_line_idx] = '\0';
                ansi::put("\r\n");
                handle(s_line);
                s_line_idx = 0;
            }
            else
            {
                ansi::put("\r\n");
                redraw_current();
            }
        }
        else if (byte == 0x08 || byte == 0x7F)
        {
            if (s_line_idx > 0)
            {
                --s_line_idx;
                ansi::put("\b \b");
            }
        }
        else if (byte >= 0x20 && s_line_idx + 1 < sizeof(s_line))
        {
            s_line[s_line_idx++] = static_cast<char>(byte);
            s_dbg_uart.write(&byte, 1);
        }
    }
}

static void log_writer(void*, const uint8_t* data, uint16_t len)
{ s_dbg_uart.write(data, len); }

void init()
{
    static log::WriterSink sink{&log_writer, nullptr};
    log::Registry::set_sink(&log::writer_sink, &sink);
    log::Registry::set_color(true);
    log::Registry::set_timestamps(false);
    log::Registry::set_global_level(log::Level::Info);

    s_gsm_uart.begin();
    s_dbg_uart.begin();

    s_modem.set_on_sms(SmsService::Received(&on_sms, nullptr));
    s_modem.set_on_call(CallService::StateChanged(&on_call, nullptr));
    s_modem.set_on_sim(Modem::SimEventCb(&on_sim_event, nullptr));
    s_modem.set_on_job(JobCallback(&on_job, nullptr));

    s_modem.housekeeping().signal_ms     = 15000;
    s_modem.housekeeping().sms_scan_ms   = 20000;
    s_modem.housekeeping().full_sweep_ms = 60000;
    s_modem.housekeeping().cleanup_ms    = 300000;

    s_modem.begin();
    draw_menu();
}

void tick()
{
    const uint32_t now = s_clk.millis();

    if (s_mode == Mode::LiveStatus && (now - s_last_draw) >= kRefreshMs)
    {
        draw_live_status();
        s_last_draw = now;
    }

    if (s_mode == Mode::Passthrough)
    {
        uint8_t  buf[64];
        uint16_t n;
        while ((n = s_gsm_uart.read(buf, sizeof(buf))) > 0)
            s_dbg_uart.write(buf, n);
    }
    else
    {
        s_modem.tick();
    }

    poll_input();
}

void on_uart_rx(UART_HandleTypeDef* huart, uint16_t size)
{
    if (huart->Instance == UART7)
        s_gsm_uart.on_rx_event(size);
    else if (huart->Instance == USART1)
        s_dbg_uart.on_rx_event(size);
}
void on_uart_error(UART_HandleTypeDef* huart)
{
    if (huart->Instance == UART7)
        s_gsm_uart.on_error();
    else if (huart->Instance == USART1)
        s_dbg_uart.on_error();
}

} // namespace cli
