#include "gsm/codec/ucs2.hpp"
#include "gsm/modem/modem.hpp"
#include "gsm_port_host.hpp"
#include <cassert>
#include <cstdio>
#include <cstring>

using namespace gsm;

static port::HostUart<2048>   uart;
static port::HostClock        clock_;
static port::HostPowerControl pwr;
static Modem                  modem(uart, clock_, kSim800, &pwr);

static void advance(uint32_t ms, uint8_t rounds = 4)
{
    for (uint8_t i = 0; i < rounds; ++i)
    {
        clock_.now += ms;
        modem.tick();
    }
}

static bool tx_has(const char* needle)
{ return std::strstr(uart.tx(), needle); }

int main()
{
    printf("Testing codecs & operator detection...\n");
    char hex[128];
    assert(codec::utf8_to_ucs2_hex("سلام", hex, sizeof(hex)) == 16);
    assert(std::strcmp(hex, "0633064406270645") == 0);

    assert(detect_operator("IRANCELL") == Operator::Irancell);
    assert(detect_operator("MTN Irancell") == Operator::Irancell);
    assert(detect_operator("IR-MCI") == Operator::Mci);
    assert(detect_operator("RighTel") == Operator::Rightel);

    assert(std::strcmp(UssdService::default_balance_code(Operator::Irancell), "*141*1#") == 0);
    assert(std::strcmp(UssdService::default_balance_code(Operator::Mci), "*140*11#") == 0);
    assert(std::strcmp(UssdService::default_balance_code(Operator::Rightel), "*140#") == 0);

    printf("Testing boot sequence...\n");
    modem.begin();
    advance(50, 1);
    assert(tx_has("AT"));
    uart.inject("OK\r\n");
    advance(50, 2);
    assert(modem.state() == ModemState::WaitingRegistration);

    // Wait for registration
    uart.clear_tx();
    advance(100, 2);
    uart.inject("\r\n+CREG: 0,1\r\n\r\nOK\r\n");
    advance(50, 2);

    // Answer bootstrap commands
    for (int i = 0; i < 15; ++i)
    {
        advance(40, 1);
        uart.inject("OK\r\n");
        advance(40, 1);
    }
    printf("State after bootstrap: %s\n", modem.state_name());
    assert(modem.ready());

    // Test USSD query
    uart.clear_tx();
    JobId ussd_job = modem.check_balance();
    assert(ussd_job != kInvalidJob);
    advance(40, 2);
    assert(tx_has("AT+CUSD="));
    uart.inject("OK\r\n");
    advance(40, 2);
    uart.inject("\r\n+CUSD: 0,\"Mojoodi: 50000 Rials\",15\r\n\r\nOK\r\n");
    advance(40, 3);
    assert(modem.current_job().kind == JobKind::None);
    printf("USSD response received successfully!\n");

    // Test SIM removal URC
    bool sim_removed_detected = false;
    modem.set_on_sim(Modem::SimEventCb(
        [](void* ctx, SimState s) {
            if (s == SimState::Removed) *static_cast<bool*>(ctx) = true;
        },
        &sim_removed_detected));

    uart.inject("\r\n+CPIN: NOT INSERTED\r\n");
    advance(40, 2);
    assert(modem.state() == ModemState::SimMissing);
    assert(sim_removed_detected);
    printf("SIM removal detected!\n");

    // Test SIM re-insertion recovery via CFUN cycle
    uart.clear_tx();
    // Advance time past CFUN cycle interval (25000ms)
    advance(26000, 2);
    assert(tx_has("AT+CFUN=0"));
    uart.inject("OK\r\n");
    advance(40, 2);
    assert(tx_has("AT+CFUN=1"));
    uart.inject("OK\r\n");
    advance(40, 2);
    // Now simulate SIM ready after CFUN reset
    uart.inject("\r\n+CPIN: READY\r\n");
    advance(40, 2);
    assert(modem.state() == ModemState::WaitingRegistration);
    printf("SIM re-insertion handled with CFUN cycle, waiting for registration!\n");

    // Test Watchdog: Queue purging stale jobs
    printf("Testing Watchdog & Queue Purge...\n");
    modem.pause_queue();
    JobId job1 = modem.send_sms("09121112233", "msg1");
    assert(job1 != kInvalidJob);
    assert(modem.queue_size() == 1);
    // Fast forward past GSM_JOB_MAX_AGE_MS (45000ms)
    advance(46000, 2);
    assert(modem.queue_size() == 0);
    printf("Stale job successfully purged by watchdog!\n");

    // Test Watchdog: Consecutive timeouts hardware power cycle
    printf("Testing Watchdog Consecutive Timeouts...\n");
    modem.resume_queue();
    uint32_t initial_pulses = pwr.pulse_count;
    for (int i = 0; i < 3; ++i)
    {
        uart.clear_tx();
        modem.send_sms("09121112233", "fail");
        advance(11000, 2); // Cause send timeout
    }
    assert(pwr.pulse_count > initial_pulses);
    printf("Watchdog triggered hardware power cycle on consecutive timeouts!\n");

    printf("ALL TESTS PASSED!\n");
    return 0;
}
