#pragma once
// Per-module quirks live here, nowhere else. Add a module = add a table.
#include "gsm/gsm_config.hpp"
#include <cstdint>

namespace gsm
{

struct DeviceTraits
{
    const char* name;
    // SIM800 in text mode + CSCS="UCS2" rejects a plain ASCII destination
    // (+CMS ERROR: 3518), so the number must be UCS2-hex too.
    bool ucs2_recipient_required;
    // AT+CSMP=<fo>,<vp>,<pid>,<dcs> applied before a UCS2 send.
    const char* csmp_ucs2;
    const char* csmp_gsm;
    const char* hangup_cmd;    // ATH vs AT+CHUP
    const char* storage_cmd;   // AT+CPMS=... or nullptr to skip
    bool        supports_clcc; // call list polling
    bool        supports_cmgd_delete_all;
    uint32_t    boot_timeout_ms;
    uint32_t    prompt_timeout_ms;
    uint32_t    send_timeout_ms;
};

// SIM800/SIM800L/SIM900 family.
inline constexpr DeviceTraits kSim800{"SIM800",
                                      /*ucs2_recipient_required*/ true,
                                      /*csmp_ucs2*/ "AT+CSMP=17,71,0,25",
                                      /*csmp_gsm*/ "AT+CSMP=17,167,0,0",
                                      /*hangup*/ "ATH",
                                      /*storage*/ "AT+CPMS=\"SM\",\"SM\",\"SM\"",
                                      /*clcc*/ true,
                                      /*cmgd_all*/ true,
                                      /*boot*/ 15000,
                                      /*prompt*/ GSM_AT_PROMPT_TIMEOUT,
                                      /*send*/ GSM_AT_CMGS_TIMEOUT};

// Quectel M08 / M66 family: same text-mode flow, cleaner hangup + storage.
inline constexpr DeviceTraits kQuectelM08{"M08",
                                          /*ucs2_recipient_required*/ true,
                                          /*csmp_ucs2*/ "AT+CSMP=17,167,0,8",
                                          /*csmp_gsm*/ "AT+CSMP=17,167,0,0",
                                          /*hangup*/ "AT+CHUP",
                                          /*storage*/ "AT+CPMS=\"ME\",\"ME\",\"ME\"",
                                          /*clcc*/ true,
                                          /*cmgd_all*/ true,
                                          /*boot*/ 20000,
                                          /*prompt*/ GSM_AT_PROMPT_TIMEOUT,
                                          /*send*/ GSM_AT_CMGS_TIMEOUT};

} // namespace gsm
