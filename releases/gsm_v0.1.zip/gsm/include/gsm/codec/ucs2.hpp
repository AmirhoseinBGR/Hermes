#pragma once
// Text-mode UCS2: everything (including the recipient number) travels as
// uppercase hex of UTF-16BE code units. This is the library default because it
// is the only reliable way to send Persian/Arabic on SIM800 in text mode.
#include <cstdint>

namespace gsm::codec
{

// UTF-8 -> UCS2 hex. Returns written length (excl. NUL), 0 on truncation.
uint16_t utf8_to_ucs2_hex(const char* utf8, char* out, uint16_t out_cap);
// UCS2 hex -> UTF-8.
uint16_t ucs2_hex_to_utf8(const char* hex, char* out, uint16_t out_cap);
// ASCII -> UCS2 hex (numbers, GSM-safe text).
uint16_t ascii_to_ucs2_hex(const char* ascii, char* out, uint16_t out_cap);

bool looks_like_ucs2_hex(const char* s);
// UCS2 code units in a UTF-8 string == SMS characters used (70 per part).
uint16_t ucs2_units(const char* utf8);
bool     is_ascii_only(const char* utf8);

} // namespace gsm::codec
