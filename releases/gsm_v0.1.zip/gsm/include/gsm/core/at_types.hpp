#pragma once
#include <cstdint>

namespace gsm
{

enum class AtStatus : uint8_t
{
    Pending = 0,
    Ok,
    Error,    // bare "ERROR"
    CmeError, // +CME ERROR: <code>
    CmsError, // +CMS ERROR: <code>
    Timeout,
    Aborted, // cancelled by queue stop / abort()
    NoDialtone,
    Busy,
    NoCarrier,
    NoAnswer,
};

struct AtResult
{
    AtStatus status = AtStatus::Pending;
    int16_t  code   = -1; // CME/CMS numeric code when applicable
    bool     ok() const { return status == AtStatus::Ok; }
};

const char* to_string(AtStatus s);
// Human hint for the CMS codes this library actually trips over (3518/520/58...).
const char* cms_error_hint(int16_t code);
const char* cme_error_hint(int16_t code);

// Observer for the single in-flight command.
class IAtObserver
{
  public:
    virtual ~IAtObserver() = default;
    virtual void on_line(const char* line, uint16_t len)
    {
        (void)line;
        (void)len;
    }
    virtual void on_prompt() {}
    virtual void on_final(const AtResult& res) { (void)res; }
};

} // namespace gsm
