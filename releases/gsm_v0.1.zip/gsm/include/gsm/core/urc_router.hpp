#pragma once
// Unsolicited result codes arrive at any time, even mid-command.
#include "gsm/util/delegate.hpp"
#include <cstdint>

namespace gsm
{

enum class Urc : uint8_t
{
    Unknown = 0,
    Ring,           // RING
    CallerId,       // +CLIP: "<number>",...
    CallEnded,      // NO CARRIER
    CallBusy,       // BUSY
    NoAnswer,       // NO ANSWER
    SmsReceived,    // +CMTI: "SM",<index>
    SmsDeliveryRep, // +CDS:/+CDSI:
    SimReady,       // +CPIN: READY
    CallReady,      // Call Ready
    SmsReady,       // SMS Ready
    PowerDown,      // NORMAL POWER DOWN / POWERED DOWN
    NetworkReg,     // +CREG:/+CGREG:
    SignalReport,   // +CSQ: (when reported unsolicited)
    Ussd,           // +CUSD:
    ModemReady,     // RDY / DY
};

struct UrcEvent
{
    Urc         kind = Urc::Unknown;
    const char* line = nullptr; // full raw line, valid during the callback only
    int32_t     arg  = -1;      // index / code when the URC carries one
};

class UrcRouter
{
  public:
    using Handler = Delegate<const UrcEvent&>;

    void set_handler(Handler h) { handler_ = h; }
    // Returns true if the line was consumed as a URC.
    bool       dispatch(const char* line, uint16_t len);
    static Urc classify(const char* line, int32_t& arg);

  private:
    Handler handler_;
};

} // namespace gsm
