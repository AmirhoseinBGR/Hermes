#pragma once
// The only class the application needs. Owns the AT engine, the services,
// the job queue and the main state machine.
#include "gsm/core/at_engine.hpp"
#include "gsm/core/service.hpp"
#include "gsm/device/device_traits.hpp"
#include "gsm/queue/job_queue.hpp"
#include "gsm/sms/sms_service.hpp"
#include "gsm/status/status_service.hpp"
#include "gsm/voice/call_service.hpp"

namespace gsm
{

enum class ModemState : uint8_t
{
    Off = 0,     // not started / powered down
    Booting,     // waiting for the module to answer AT
    Configuring, // applying the bootstrap command list
    Ready,       // idle, housekeeping allowed
    Working,     // a job is running (see activity()/step())
    Ringing,     // incoming call pending
    InCall,      // voice call up
    Fault,       // gave up, needs reset()
};

const char* to_string(ModemState s);

struct HousekeepingConfig
{
    bool     enabled       = true;
    uint32_t signal_ms     = 10000;  // AT+CSQ
    uint32_t full_sweep_ms = 60000;  // CSQ + CREG + CPIN + CPMS + COPS
    uint32_t sms_scan_ms   = 30000;  // AT+CMGL="REC UNREAD"
    uint32_t cleanup_ms    = 300000; // delete read messages
};

class Modem final : public IAtObserver
{
  public:
    Modem(hal::IUart& uart, hal::IClock& clock, const DeviceTraits& traits = kSim800,
          hal::IPowerControl* power = nullptr);

    void begin();
    void tick();
    void reset();       // full re-bootstrap
    void power_cycle(); // uses IPowerControl when provided

    // --- jobs ---------------------------------------------------------------
    JobId send_sms(const char* number, const char* utf8_text, JobCallback cb = {},
                   SmsEncoding enc = SmsEncoding::Auto);
    JobId read_sms(int16_t index, JobCallback cb = {});
    JobId scan_sms(JobCallback cb = {});
    JobId delete_read_sms(JobCallback cb = {});
    JobId dial(const char* number, JobCallback cb = {});
    JobId answer(JobCallback cb = {});
    JobId hang_up(JobCallback cb = {}); // urgent
    JobId refresh_status(JobCallback cb = {});

    // --- queue control ------------------------------------------------------
    void       pause_queue() { queue_.pause(); }
    void       resume_queue() { queue_.resume(); }
    bool       queue_paused() const { return queue_.paused(); }
    void       stop_all(bool also_pause = true); // abort running + drop queued
    bool       cancel(JobId id);
    uint8_t    queue_size() const { return queue_.size(); }
    const Job* queued(uint8_t i) const { return queue_.at(i); }
    const Job& current_job() const { return current_; }

    // --- observation --------------------------------------------------------
    ModemState          state() const { return state_; }
    const char*         state_name() const { return to_string(state_); }
    const char*         activity() const { return to_string(current_.kind); }
    const char*         step() const;
    bool                ready() const { return state_ == ModemState::Ready; }
    const ModemStatus&  status() const { return status_; }
    SmsService&         sms() { return sms_; }
    CallService&        call() { return call_; }
    AtEngine&           at() { return at_; }
    HousekeepingConfig& housekeeping() { return hk_; }

    void set_on_sms(SmsService::Received cb) { sms_.set_on_received(cb); }
    void set_on_call(CallService::StateChanged cb) { call_.set_on_state(cb); }
    void set_on_job(JobCallback cb) { on_job_ = cb; }
    void set_on_urc(UrcRouter::Handler cb) { user_urc_ = cb; }
    void set_auto_read_sms(bool on) { auto_read_ = on; }

    // IAtObserver: used for the bootstrap sequence only.
    void on_line(const char* line, uint16_t len) override;
    void on_final(const AtResult& res) override;

  private:
    void        handle_urc(const UrcEvent& ev);
    static void urc_trampoline(void* ctx, const UrcEvent& ev);
    void        enter(ModemState s);
    JobId       enqueue(Job& job, JobCallback cb);
    bool        start_job(Job& job);
    void        finish_job(const AtResult& res);
    void        pump_services();
    void        pump_housekeeping();
    void        flush_cancelled();
    IService*   service_for(JobKind kind);

    hal::IUart&         uart_;
    hal::IClock&        clock_;
    const DeviceTraits& traits_;
    hal::IPowerControl* power_;

    UrcRouter     urc_;
    AtEngine      at_;
    SessionState  session_;
    ModemStatus   status_;
    SmsService    sms_;
    CallService   call_;
    StatusService stat_;

    JobQueue           queue_;
    Job                current_;
    JobCallback        current_cb_;
    JobCallback        on_job_;
    UrcRouter::Handler user_urc_;

    ModemState         state_        = ModemState::Off;
    uint8_t            boot_probe_   = 0;
    uint8_t            boot_index_   = 0;
    bool               boot_issued_  = false;
    uint32_t           state_since_  = 0;
    uint32_t           last_signal_  = 0;
    uint32_t           last_sweep_   = 0;
    uint32_t           last_scan_    = 0;
    uint32_t           last_cleanup_ = 0;
    JobId              next_id_      = 1;
    bool               auto_read_    = true;
    HousekeepingConfig hk_;
};

} // namespace gsm
