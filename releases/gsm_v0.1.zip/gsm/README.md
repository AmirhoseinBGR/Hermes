# gsm-modem

Non-blocking C++17 driver for SIM800/SIM900 and Quectel M08/M66.
SMS (UCS2 text mode by default, Persian-safe) + voice calls, a main/sub state
machine, a job queue and idle housekeeping. No STL, no dynamic allocation,
no exceptions/RTTI. Default target: STM32 (CubeMX HAL); Arduino and a desktop
test port included.

```cpp
static gsm::port::Stm32Uart<256> uart(&huart7);
static gsm::port::Stm32Clock clk;
static gsm::Modem modem(uart, clk, gsm::kSim800);   // or gsm::kQuectelM08

modem.begin();
while (true) {
  modem.tick();                                     // never blocks
  if (modem.ready()) modem.send_sms("09037744527", "سلام");
}
```

- `docs/ARCHITECTURE.md` - layers, state machine, queue, extension points (fa)
- `docs/QUIRKS.md` - every SIM800 trap the code already works around (fa)
- `tests/host_smoke.cpp` - drives the full FSM against a scripted modem on your PC

Build the desktop test:
```
cmake -B build -DGSM_BUILD_TESTS=ON && cmake --build build && ./build/host_smoke
```

Layout: `include/gsm/{util,log,hal,core,codec,sms,voice,status,queue,modem,device,tools}`,
`src/`, `ports/{stm32,arduino,host}`, `examples/`, `docs/`, `tests/`.
