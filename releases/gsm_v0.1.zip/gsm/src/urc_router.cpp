#include "gsm/core/urc_router.hpp"
#include "gsm/util/static_string.hpp"

namespace gsm
{

Urc UrcRouter::classify(const char* line, int32_t& arg)
{
    arg = -1;
    if (!line || !*line) return Urc::Unknown;

    if (str_starts_with(line, "RING")) return Urc::Ring;
    if (str_starts_with(line, "+CLIP:")) return Urc::CallerId;
    if (str_starts_with(line, "NO CARRIER")) return Urc::CallEnded;
    if (str_starts_with(line, "BUSY")) return Urc::CallBusy;
    if (str_starts_with(line, "NO ANSWER")) return Urc::NoAnswer;
    if (str_starts_with(line, "+CMTI:"))
    {
        parse_int(line + 6, arg); // storage index
        return Urc::SmsReceived;
    }
    if (str_starts_with(line, "+CDSI:") || str_starts_with(line, "+CDS:"))
        return Urc::SmsDeliveryRep;
    if (str_starts_with(line, "+CPIN: READY")) return Urc::SimReady;
    if (str_starts_with(line, "Call Ready")) return Urc::CallReady;
    if (str_starts_with(line, "SMS Ready")) return Urc::SmsReady;
    if (str_starts_with(line, "NORMAL POWER DOWN") || str_starts_with(line, "POWERED DOWN"))
        return Urc::PowerDown;
    if (str_starts_with(line, "+CREG:") || str_starts_with(line, "+CGREG:"))
    {
        parse_int(line + 6, arg);
        return Urc::NetworkReg;
    }
    if (str_starts_with(line, "+CUSD:")) return Urc::Ussd;
    // Boot banners differ per module: SIM800 "RDY", some clones print "DY".
    if (str_starts_with(line, "RDY") || str_starts_with(line, "DY")) return Urc::ModemReady;
    return Urc::Unknown;
}

bool UrcRouter::dispatch(const char* line, uint16_t len)
{
    int32_t   arg  = -1;
    const Urc kind = classify(line, arg);
    if (kind == Urc::Unknown) return false;
    (void)len;
    UrcEvent ev{kind, line, arg};
    if (handler_) handler_(ev);
    return true;
}

} // namespace gsm
