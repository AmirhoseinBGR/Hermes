#include "gsm/status/status_service.hpp"
#include "gsm/log/log.hpp"
#include <cstring>

namespace gsm
{

static const log::Channel kLog{"stat", log::Level::Debug};

const char* to_string(StatusStep s)
{
    switch (s)
    {
    case StatusStep::Idle:
        return "idle";
    case StatusStep::Signal:
        return "csq";
    case StatusStep::Registration:
        return "creg";
    case StatusStep::SimPin:
        return "cpin";
    case StatusStep::Storage:
        return "cpms";
    case StatusStep::Operator:
        return "cops";
    case StatusStep::Done:
        return "done";
    }
    return "?";
}

bool StatusService::start(StatusStep first)
{
    if (active()) return false;
    step_   = first;
    issued_ = false;
    sweep_  = false;
    result_ = AtResult{};
    return true;
}

bool StatusService::start_full_sweep()
{
    if (!start(StatusStep::Signal)) return false;
    sweep_ = true;
    return true;
}

void StatusService::cancel()
{
    if (active()) at_.abort();
    step_   = StatusStep::Idle;
    issued_ = false;
}

void StatusService::pump()
{
    if (!active() || issued_) return;
    switch (step_)
    {
    case StatusStep::Signal:
        issued_ = at_.execute("AT+CSQ", 1000, this);
        return;
    case StatusStep::Registration:
        issued_ = at_.execute("AT+CREG?", 1000, this);
        return;
    case StatusStep::SimPin:
        issued_ = at_.execute("AT+CPIN?", 5000, this);
        return;
    case StatusStep::Storage:
        if (!traits_.storage_cmd)
        {
            step_ = StatusStep::Operator;
            return;
        }
        issued_ = at_.execute("AT+CPMS?", 2000, this);
        return;
    case StatusStep::Operator:
        issued_ = at_.execute("AT+COPS?", 5000, this);
        return;
    default:
        return;
    }
}

void StatusService::on_line(const char* line, uint16_t len)
{
    (void)len;
    if (str_starts_with(line, "+CSQ:"))
    {
        char f[8];
        if (csv_field(line + 5, 0, f, sizeof(f)))
        {
            int32_t v = 0;
            if (parse_int(f, v))
            {
                status_.csq_raw  = static_cast<uint8_t>(v);
                status_.rssi_dbm = (v == 99) ? 0 : static_cast<int8_t>(-113 + 2 * v);
            }
        }
        if (csv_field(line + 5, 1, f, sizeof(f)))
        {
            int32_t v = 0;
            if (parse_int(f, v)) status_.ber = static_cast<uint8_t>(v);
        }
        return;
    }
    if (str_starts_with(line, "+CREG:"))
    {
        char f[8];
        if (csv_field(line + 6, 1, f, sizeof(f)))
        {
            int32_t v = 0;
            if (parse_int(f, v))
            {
                status_.registration  = static_cast<RegState>(v);
                status_.network_ready = (v == 1 || v == 5);
            }
        }
        return;
    }
    if (str_starts_with(line, "+CPIN:"))
    {
        status_.sim_ready = std::strstr(line, "READY") != nullptr;
        return;
    }
    if (str_starts_with(line, "+CPMS:"))
    {
        char f[12];
        if (csv_field(line + 6, 1, f, sizeof(f)))
        {
            int32_t v = 0;
            if (parse_int(f, v)) status_.sms_used = static_cast<uint8_t>(v);
        }
        if (csv_field(line + 6, 2, f, sizeof(f)))
        {
            int32_t v = 0;
            if (parse_int(f, v)) status_.sms_total = static_cast<uint8_t>(v);
        }
        return;
    }
    if (str_starts_with(line, "+COPS:"))
    {
        char f[24];
        if (csv_field(line + 6, 2, f, sizeof(f))) status_.operator_name.assign(f);
        return;
    }
}

void StatusService::on_final(const AtResult& res)
{
    issued_               = false;
    result_               = res;
    status_.updated_at_ms = at_.now();
    if (!sweep_)
    {
        step_ = StatusStep::Idle;
        return;
    }
    switch (step_)
    {
    case StatusStep::Signal:
        step_ = StatusStep::Registration;
        break;
    case StatusStep::Registration:
        step_ = StatusStep::SimPin;
        break;
    case StatusStep::SimPin:
        step_ = StatusStep::Storage;
        break;
    case StatusStep::Storage:
        step_ = StatusStep::Operator;
        break;
    default:
        kLog.debug("csq=%u(%ddBm) reg=%u sim=%u sms=%u/%u op=%s", status_.csq_raw, status_.rssi_dbm,
                   static_cast<unsigned>(status_.registration), status_.sim_ready, status_.sms_used,
                   status_.sms_total, status_.operator_name.c_str());
        step_ = StatusStep::Idle;
        break;
    }
}

} // namespace gsm
