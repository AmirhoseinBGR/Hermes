#include "gsm/modem/modem.hpp"
#include "gsm/log/log.hpp"

namespace gsm
{

static const log::Channel kLog{"modem", log::Level::Info};

// Bootstrap list: applied once after the module answers AT.
struct BootCmd
{
    const char* cmd;
    uint32_t    timeout_ms;
    bool        optional;
};
static const BootCmd kBoot[] = {
    {"ATE0", 1000, false},             // kill echo, parsing gets trivial
    {"AT+CMEE=2", 1000, true},         // verbose errors
    {"AT+CLIP=1", 1000, true},         // caller id on RING
    {"AT+CMGF=1", 1000, false},        // text mode
    {"AT+CSMP=17,0,8,0", 1000, true},  // +CMTI on new SMS, no auto-dump
    {"AT+CSCS=\"UCS2\"", 1000, false}, // library default charset
    {nullptr, 0, false},               // slot for traits_.csmp_ucs2
    {nullptr, 0, false},               // slot for traits_.storage_cmd
};
static constexpr uint8_t kBootCount = sizeof(kBoot) / sizeof(kBoot[0]);

const char* to_string(ModemState s)
{
    switch (s)
    {
    case ModemState::Off:
        return "off";
    case ModemState::Booting:
        return "booting";
    case ModemState::Configuring:
        return "configuring";
    case ModemState::Ready:
        return "ready";
    case ModemState::Working:
        return "working";
    case ModemState::Ringing:
        return "ringing";
    case ModemState::InCall:
        return "in-call";
    case ModemState::Fault:
        return "fault";
    }
    return "?";
}

Modem::Modem(hal::IUart& uart, hal::IClock& clock, const DeviceTraits& traits,
             hal::IPowerControl* power)
    : uart_(uart), clock_(clock), traits_(traits), power_(power), at_(uart, clock, urc_),
      sms_(at_, session_, traits), call_(at_, session_, traits), stat_(at_, status_, traits)
{ urc_.set_handler(UrcRouter::Handler(&Modem::urc_trampoline, this)); }

void Modem::urc_trampoline(void* ctx, const UrcEvent& ev)
{ static_cast<Modem*>(ctx)->handle_urc(ev); }

namespace
{
hal::IClock* g_log_clock = nullptr;
uint32_t     log_now()
{ return g_log_clock ? g_log_clock->millis() : 0u; }
} // namespace

void Modem::begin()
{
    // Timestamped logs for free; the app can install its own hook afterwards.
    g_log_clock = &clock_;
    log::Registry::set_clock(&log_now);
    session_.invalidate();
    boot_probe_  = 0;
    boot_index_  = 0;
    boot_issued_ = false;
    enter(ModemState::Booting);
    kLog.info("begin (%s)", traits_.name);
}

void Modem::reset()
{
    at_.abort();
    stop_all(false);
    begin();
}

void Modem::power_cycle()
{
    if (!power_)
    {
        reset();
        return;
    }
    power_->power_key(true);
    // Caller keeps ticking; the pulse width is platform business.
    power_->power_key(false);
    reset();
}

void Modem::enter(ModemState s)
{
    if (state_ == s) return;
    kLog.debug("%s -> %s", to_string(state_), to_string(s));
    state_       = s;
    state_since_ = clock_.millis();
}

const char* Modem::step() const
{
    switch (state_)
    {
    case ModemState::Booting:
        return "probe-at";
    case ModemState::Configuring:
        return "bootstrap";
    default:
        break;
    }
    switch (current_.kind)
    {
    case JobKind::SmsSend:
    case JobKind::SmsRead:
    case JobKind::SmsScan:
    case JobKind::SmsDeleteIndex:
    case JobKind::SmsDeleteRead:
        return sms_.step_name();
    case JobKind::CallDial:
    case JobKind::CallAnswer:
    case JobKind::CallHangup:
        return call_.step_name();
    case JobKind::StatusSweep:
        return stat_.step_name();
    default:
        return "idle";
    }
}

IService* Modem::service_for(JobKind kind)
{
    switch (kind)
    {
    case JobKind::SmsSend:
    case JobKind::SmsRead:
    case JobKind::SmsScan:
    case JobKind::SmsDeleteIndex:
    case JobKind::SmsDeleteRead:
        return &sms_;
    case JobKind::CallDial:
    case JobKind::CallAnswer:
    case JobKind::CallHangup:
        return &call_;
    case JobKind::StatusSweep:
        return &stat_;
    default:
        return nullptr;
    }
}

// --- job api -----------------------------------------------------------------
JobId Modem::enqueue(Job& job, JobCallback cb)
{
    job.id = next_id_++;
    if (next_id_ == 0) next_id_ = 1;
    job.enqueued_ms = clock_.millis();
    job.state       = JobState::Queued;
    if (!queue_.push(job, cb))
    {
        kLog.warn("queue full, dropped %s", to_string(job.kind));
        return kInvalidJob;
    }
    kLog.debug("queued #%u %s (depth=%u)", job.id, to_string(job.kind), queue_.size());
    return job.id;
}

JobId Modem::send_sms(const char* number, const char* utf8_text, JobCallback cb, SmsEncoding enc)
{
    Job job;
    job.kind = JobKind::SmsSend;
    job.number.assign(number);
    job.text.assign(utf8_text);
    job.encoding     = enc;
    job.max_attempts = 2;
    return enqueue(job, cb);
}

JobId Modem::read_sms(int16_t index, JobCallback cb)
{
    Job job;
    job.kind  = JobKind::SmsRead;
    job.index = index;
    return enqueue(job, cb);
}

JobId Modem::scan_sms(JobCallback cb)
{
    Job job;
    job.kind = JobKind::SmsScan;
    return enqueue(job, cb);
}

JobId Modem::delete_read_sms(JobCallback cb)
{
    Job job;
    job.kind = JobKind::SmsDeleteRead;
    return enqueue(job, cb);
}

JobId Modem::dial(const char* number, JobCallback cb)
{
    Job job;
    job.kind = JobKind::CallDial;
    job.number.assign(number);
    return enqueue(job, cb);
}

JobId Modem::answer(JobCallback cb)
{
    Job job;
    job.kind   = JobKind::CallAnswer;
    job.urgent = true;
    return enqueue(job, cb);
}

JobId Modem::hang_up(JobCallback cb)
{
    Job job;
    job.kind   = JobKind::CallHangup;
    job.urgent = true;
    return enqueue(job, cb);
}

JobId Modem::refresh_status(JobCallback cb)
{
    Job job;
    job.kind = JobKind::StatusSweep;
    return enqueue(job, cb);
}

bool Modem::cancel(JobId id)
{
    if (current_.id == id && current_.state == JobState::Running)
    {
        IService* svc = service_for(current_.kind);
        if (svc) svc->cancel();
        AtResult res{AtStatus::Aborted, -1};
        finish_job(res);
        return true;
    }
    Job         job;
    JobCallback cb;
    if (!queue_.cancel(id, job, cb)) return false;
    cb(job);
    on_job_(job);
    return true;
}

void Modem::stop_all(bool also_pause)
{
    if (also_pause) queue_.pause();
    if (current_.state == JobState::Running)
    {
        IService* svc = service_for(current_.kind);
        if (svc) svc->cancel();
        AtResult res{AtStatus::Aborted, -1};
        finish_job(res);
    }
    queue_.clear();
    flush_cancelled();
    kLog.warn("stop_all (queue %s)", queue_.paused() ? "paused" : "open");
}

void Modem::flush_cancelled()
{
    Job         job;
    JobCallback cb;
    while (queue_.take_cancelled(job, cb))
    {
        cb(job);
        on_job_(job);
    }
}

bool Modem::start_job(Job& job)
{
    IService* svc = service_for(job.kind);
    if (!svc) return false;
    bool started = false;
    ++job.attempts;
    switch (job.kind)
    {
    case JobKind::SmsSend:
        started = sms_.start_send(job.number.c_str(), job.text.c_str(), job.encoding);
        break;
    case JobKind::SmsRead:
        started = sms_.start_read(job.index);
        break;
    case JobKind::SmsScan:
        started = sms_.start_scan_unread();
        break;
    case JobKind::SmsDeleteIndex:
        started = sms_.start_delete_index(job.index);
        break;
    case JobKind::SmsDeleteRead:
        started = sms_.start_delete_read();
        break;
    case JobKind::CallDial:
        started = call_.start_dial(job.number.c_str());
        break;
    case JobKind::CallAnswer:
        started = call_.start_answer();
        break;
    case JobKind::CallHangup:
        started = call_.start_hangup();
        break;
    case JobKind::StatusSweep:
        started = stat_.start_full_sweep();
        break;
    default:
        break;
    }
    if (!started) return false;
    job.state = JobState::Running;
    enter(ModemState::Working);
    kLog.info("run #%u %s (try %u/%u)", job.id, to_string(job.kind), job.attempts,
              job.max_attempts);
    return true;
}

void Modem::finish_job(const AtResult& res)
{
    current_.result = res;
    if (current_.kind == JobKind::SmsSend) current_.reference = sms_.send_report().reference;

    const bool retryable =
        !res.ok() && res.status != AtStatus::Aborted && current_.attempts < current_.max_attempts;
    if (retryable)
    {
        kLog.warn("#%u %s failed (%s), retrying", current_.id, to_string(current_.kind),
                  to_string(res.status));
        current_.state = JobState::Queued;
        return; // re-dispatched by pump_services on the next tick
    }

    current_.state =
        res.ok() ? JobState::Succeeded
                 : (res.status == AtStatus::Aborted ? JobState::Cancelled : JobState::Failed);
    kLog.info("#%u %s -> %s", current_.id, to_string(current_.kind), to_string(current_.state));
    current_cb_(current_);
    on_job_(current_);
    current_.clear();
    current_cb_.clear();
    if (call_.in_call())
        enter(ModemState::InCall);
    else if (call_.ringing())
        enter(ModemState::Ringing);
    else
        enter(ModemState::Ready);
}

// --- urc ---------------------------------------------------------------------
void Modem::handle_urc(const UrcEvent& ev)
{
    switch (ev.kind)
    {
    case Urc::Ring:
        call_.notify_ring(nullptr);
        if (state_ == ModemState::Ready) enter(ModemState::Ringing);
        break;
    case Urc::CallerId: {
        char num[GSM_SMS_NUMBER_BYTES];
        csv_field(ev.line + 6, 0, num, sizeof(num));
        call_.notify_ring(num);
        if (state_ == ModemState::Ready) enter(ModemState::Ringing);
        break;
    }
    case Urc::CallEnded:
    case Urc::NoAnswer:
        call_.notify_hangup();
        if (state_ == ModemState::InCall || state_ == ModemState::Ringing) enter(ModemState::Ready);
        break;
    case Urc::CallBusy:
        call_.notify_busy();
        break;
    case Urc::SmsReceived:
        kLog.info("new sms at index %ld", static_cast<long>(ev.arg));
        if (auto_read_ && ev.arg >= 0) read_sms(static_cast<int16_t>(ev.arg));
        break;
    case Urc::SimReady:
        status_.sim_ready = true;
        break;
    case Urc::NetworkReg:
        status_.network_ready = (ev.arg == 1 || ev.arg == 5);
        break;
    case Urc::PowerDown:
        kLog.error("module powered down");
        session_.invalidate();
        enter(ModemState::Off);
        break;
    case Urc::ModemReady:
        kLog.debug("module banner");
        break;
    default:
        break;
    }
    user_urc_(ev);
}

// --- bootstrap observer ------------------------------------------------------
void Modem::on_line(const char* line, uint16_t len)
{
    (void)line;
    (void)len;
}

void Modem::on_final(const AtResult& res)
{
    boot_issued_ = false;
    if (state_ == ModemState::Booting)
    {
        if (res.ok())
        {
            kLog.info("module responsive");
            boot_index_ = 0;
            enter(ModemState::Configuring);
        }
        else if (++boot_probe_ > 10)
        {
            kLog.error("no answer from module");
            enter(ModemState::Fault);
        }
        return;
    }
    if (state_ == ModemState::Configuring)
    {
        const BootCmd& bc = kBoot[boot_index_];
        if (!res.ok() && !bc.optional)
        {
            kLog.error("bootstrap step %u failed", boot_index_);
            enter(ModemState::Fault);
            return;
        }
        if (boot_index_ == 0) session_.echo_off = res.ok();
        if (boot_index_ == 4) session_.text_mode = res.ok();
        if (boot_index_ == 5) session_.charset = res.ok() ? Charset::Ucs2 : Charset::Unknown;
        if (boot_index_ == 6) session_.csmp_ucs2 = res.ok();
        if (boot_index_ == 7) session_.storage_ready = res.ok();
        if (++boot_index_ >= kBootCount)
        {
            kLog.info("ready");
            enter(ModemState::Ready);
            last_signal_ = last_sweep_ = last_scan_ = last_cleanup_ = clock_.millis();
        }
    }
}

// --- scheduler ---------------------------------------------------------------
void Modem::pump_services()
{
    if (current_.state == JobState::Running)
    {
        IService* svc = service_for(current_.kind);
        if (svc)
        {
            if (svc->active())
            {
                svc->pump();
                return;
            }
            finish_job(svc->result());
            return;
        }
    }
    // A retry left the job in Queued state: run it again.
    if (current_.kind != JobKind::None && current_.state == JobState::Queued)
    {
        if (start_job(current_)) return;
    }

    if (current_.kind != JobKind::None) return;
    Job         job;
    JobCallback cb;
    if (!queue_.pop(job, cb)) return;
    current_    = job;
    current_cb_ = cb;
    if (!start_job(current_))
    {
        AtResult res{AtStatus::Error, -1};
        finish_job(res);
    }
}

void Modem::pump_housekeeping()
{
    if (!hk_.enabled) return;
    const uint32_t now = clock_.millis();
    if (hk_.full_sweep_ms && hal::elapsed(now, last_sweep_, hk_.full_sweep_ms))
    {
        last_sweep_ = last_signal_ = now;
        stat_.start_full_sweep();
        return;
    }
    if (hk_.signal_ms && hal::elapsed(now, last_signal_, hk_.signal_ms))
    {
        last_signal_ = now;
        stat_.start(StatusStep::Signal);
        return;
    }
    if (hk_.sms_scan_ms && hal::elapsed(now, last_scan_, hk_.sms_scan_ms))
    {
        last_scan_ = now;
        scan_sms();
        return;
    }
    if (hk_.cleanup_ms && hal::elapsed(now, last_cleanup_, hk_.cleanup_ms))
    {
        last_cleanup_ = now;
        if (status_.sms_used) delete_read_sms();
        return;
    }
}

void Modem::tick()
{
    at_.tick();
    flush_cancelled();

    switch (state_)
    {
    case ModemState::Off:
    case ModemState::Fault:
        return;

    case ModemState::Booting:
        if (!boot_issued_ && at_.idle()) boot_issued_ = at_.execute("AT", 1000, this);
        return;

    case ModemState::Configuring: {
        if (boot_issued_ || !at_.idle()) return;
        const BootCmd& bc      = kBoot[boot_index_];
        const char*    cmd     = bc.cmd;
        uint32_t       timeout = bc.timeout_ms ? bc.timeout_ms : 1000;
        if (boot_index_ == 6) cmd = traits_.csmp_ucs2;
        if (boot_index_ == 7) cmd = traits_.storage_cmd;
        if (!cmd)
        { // nothing to do for this slot
            AtResult res{AtStatus::Ok, -1};
            on_final(res);
            return;
        }
        boot_issued_ = at_.execute(cmd, timeout, this);
        return;
    }

    default:
        break;
    }

    if (!at_.idle()) return;

    // Services always win over new work: they own the in-flight sub-FSM.
    if (stat_.active() && current_.kind != JobKind::StatusSweep)
    {
        stat_.pump();
        return;
    }
    pump_services();

    if (current_.kind == JobKind::None && at_.idle() && !stat_.active())
    {
        if (call_.in_call())
            enter(ModemState::InCall);
        else if (call_.ringing())
            enter(ModemState::Ringing);
        else
        {
            enter(ModemState::Ready);
            pump_housekeeping();
        }
    }
}

} // namespace gsm
