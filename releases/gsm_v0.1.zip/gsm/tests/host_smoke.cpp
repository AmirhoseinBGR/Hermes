// Desktop smoke test: drives the whole FSM against a scripted modem.
#include "gsm/codec/ucs2.hpp"
#include "gsm/modem/modem.hpp"
#include "gsm_port_host.hpp"
#include <cassert>
#include <cstdio>
#include <cstring>

using namespace gsm;

static port::HostUart<2048> uart;
static port::HostClock      clock_;
static Modem                modem(uart, clock_, kSim800);

static void advance(uint32_t ms, uint8_t rounds = 4)
{
    for (uint8_t i = 0; i < rounds; ++i)
    {
        clock_.now += ms;
        modem.tick();
    }
}

static bool tx_has(const char* needle)
{ return std::strstr(uart.tx(), needle); }

int main()
{
    char hex[128];
    assert(codec::utf8_to_ucs2_hex("سلام", hex, sizeof(hex)) == 16);
    assert(std::strcmp(hex, "0633064406270645") == 0);
    char back[64];
    codec::ucs2_hex_to_utf8("0633064406270645", back, sizeof(back));
    assert(std::strcmp(back, "سلام") == 0);
    codec::ascii_to_ucs2_hex("+989037744527", hex, sizeof(hex));
    assert(std::strcmp(hex, "002B003900380039003000330037003700340034003500320037") == 0);

    PhoneNumber pn("09037744527");
    assert(std::strcmp(pn.e164(), "+989037744527") == 0);

    modem.begin();
    // boot probe + bootstrap list
    for (int i = 0; i < 12; ++i)
    {
        advance(40, 1);
        uart.inject("OK\r\n");
        advance(40, 1);
    }
    printf("state after boot: %s\n", modem.state_name());
    assert(modem.ready());

    uart.clear_tx();
    const JobId id = modem.send_sms("09037744527", "سلام");
    assert(id != kInvalidJob);
    advance(40, 2);
    assert(tx_has("AT+CMGS=\"002B003900380039003000330037003700340034003500320037\""));
    uart.inject("\r\n> ");
    advance(40, 2);
    assert(tx_has("0633064406270645"));
    assert(!tx_has("0633064406270645\r\n")); // no CRLF before Ctrl+Z
    uart.inject("\r\n+CMGS: 7\r\n\r\nOK\r\n");
    advance(40, 3);
    assert(modem.current_job().kind == JobKind::None);
    printf("sms ok, state=%s\n", modem.state_name());

    // incoming call + urgent hangup jumping the queue
    uart.inject("\r\nRING\r\n\r\n+CLIP: \"09121112233\",161,,,,0\r\n");
    advance(40, 2);
    assert(modem.state() == ModemState::Ringing);
    modem.hang_up();
    advance(40, 2);
    assert(tx_has("ATH"));
    uart.inject("OK\r\n");
    advance(40, 2);
    assert(modem.call().state() == CallState::Idle);

    // inbound sms -> auto read + delete
    uart.clear_tx();
    uart.inject("\r\n+CMTI: \"SM\",3\r\n");
    advance(40, 2);
    assert(tx_has("AT+CMGR=3"));
    uart.inject("\r\n+CMGR: \"REC "
                "UNREAD\",\"002B003900380039003000330037003700340034003500320037\",,\"25/09/"
                "12,21:03:44+14\"\r\n0633064406270645\r\n\r\nOK\r\n");
    advance(40, 3);
    printf("inbox: %s / %s\n", modem.sms().last_message().number.c_str(),
           modem.sms().last_message().text.c_str());
    assert(std::strcmp(modem.sms().last_message().text.c_str(), "سلام") == 0);
    uart.inject("OK\r\n");
    advance(40, 3);

    // queue control
    modem.pause_queue();
    modem.send_sms("09121112233", "one");
    modem.send_sms("09121112233", "two");
    assert(modem.queue_size() == 2);
    modem.stop_all();
    assert(modem.queue_size() == 0);

    // signal parsing
    modem.resume_queue();
    modem.refresh_status();
    advance(40, 2);
    uart.inject("\r\n+CSQ: 23,0\r\n\r\nOK\r\n");
    advance(40, 3);
    printf("csq=%u rssi=%ddBm bars=%u\n", modem.status().csq_raw, modem.status().rssi_dbm,
           modem.status().signal_bars());
    assert(modem.status().csq_raw == 23);

    printf("ALL GOOD\n");
    return 0;
}
